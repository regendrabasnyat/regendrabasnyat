import type { NextConfig } from "next";

/**
 * Legacy V2 routes are permanently redirected to their V3 equivalents so
 * existing inbound links, ads and search rankings keep resolving.
 * NOTE: /blog/:slug is intentionally NOT redirected — migrate the existing
 * posts into /insights/:slug first, then add a slug-preserving redirect.
 */
const isStatic = process.env.STATIC_EXPORT === "1";

const nextConfig: NextConfig = isStatic
  ? {
      // Static build for Hostinger shared hosting (public_html). Redirects,
      // headers and the contact form are handled by .htaccess + contact.php.
      output: "export",
      trailingSlash: true,
      images: { unoptimized: true },
    }
  : {
  poweredByHeader: false,
  images: { formats: ["image/avif", "image/webp"] },
  async redirects() {
    return [
      { source: "/services", destination: "/teams", permanent: true },
      { source: "/services/hire", destination: "/teams#embedded-engineer", permanent: true },
      { source: "/services/squads", destination: "/teams#engineering-pod", permanent: true },
      { source: "/services/mvp", destination: "/teams#engineering-team", permanent: true },
      { source: "/services/modernization", destination: "/engineering", permanent: true },
      { source: "/case-studies", destination: "/engineering", permanent: true },
      { source: "/case-studies/:slug*", destination: "/engineering", permanent: true },
      { source: "/work", destination: "/engineering", permanent: true },
      { source: "/get-proposal", destination: "/contact", permanent: true },
    ];
  },
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
        ],
      },
    ];
  },
};

export default nextConfig;
