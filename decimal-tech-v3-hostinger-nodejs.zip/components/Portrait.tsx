import Image from "next/image";

/**
 * Real photographs only. Drop files at /public/images/team/<firstname>.jpg and
 * pass `src`. Until then a clearly-labelled placeholder is shown —
 * never a generated face.
 */
export function Portrait({ name, src, priority, sizes = "(min-width: 1000px) 25vw, 50vw" }: { name: string; src?: string; priority?: boolean; sizes?: string }) {
  return (
    <div className="portrait">
      {src ? (
        <Image src={src} alt={`Portrait of ${name}`} fill sizes={sizes} priority={priority} />
      ) : (
        <div className="portrait__placeholder" role="img" aria-label={`Photo of ${name} coming soon`}>
          <span className="portrait__initial" aria-hidden="true">{name[0]}</span>
          <span className="portrait__tag" aria-hidden="true">Photo pending</span>
        </div>
      )}
    </div>
  );
}
