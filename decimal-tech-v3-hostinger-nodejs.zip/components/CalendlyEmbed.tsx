"use client";
import { useEffect, useRef, useState } from "react";
import { site } from "@/lib/site";

const SCRIPT = "https://assets.calendly.com/assets/external/widget.js";

/** Themed Calendly inline widget. Loads the script once, on demand, and re-renders on theme change. */
export function CalendlyEmbed() {
  const host = useRef<HTMLDivElement>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const el = host.current;
    if (!el || !site.bookingUrl) return;

    const paint = () => {
      const dark = document.documentElement.dataset.theme === "dark";
      const params = new URLSearchParams({
        hide_gdpr_banner: "1",
        background_color: dark ? "15171b" : "ffffff",
        text_color: dark ? "f2f2ef" : "0a0b0d",
        primary_color: "ee3b24",
      });
      el.innerHTML = "";
      const w = window as unknown as { Calendly?: { initInlineWidget: (o: { url: string; parentElement: HTMLElement }) => void } };
      if (!w.Calendly) return;
      w.Calendly.initInlineWidget({ url: `${site.bookingUrl}?${params}`, parentElement: el });
    };

    let script = document.querySelector<HTMLScriptElement>(`script[src="${SCRIPT}"]`);
    if (!script) {
      script = document.createElement("script");
      script.src = SCRIPT;
      script.async = true;
      script.onerror = () => setFailed(true);
      document.body.appendChild(script);
    }
    script.addEventListener("load", paint);
    if ((window as unknown as { Calendly?: unknown }).Calendly) paint();

    const mo = new MutationObserver(paint);
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    return () => {
      mo.disconnect();
      script?.removeEventListener("load", paint);
    };
  }, []);

  return (
    <div className="calendly">
      <div ref={host} className="calendly__widget" role="region" aria-label="Booking calendar" />
      <p className="calendly__fallback small muted">
        Calendar not loading?{" "}
        <a className="text-link" href={site.bookingUrl} target="_blank" rel="noopener noreferrer">
          Open it in a new tab
        </a>
        {failed ? " — the booking script was blocked in your browser." : "."}
      </p>
    </div>
  );
}
