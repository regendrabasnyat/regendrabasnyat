import { PageHero } from "./PageHero";
import { site } from "@/lib/site";

/**
 * MIGRATION REQUIRED: paste the existing V2 policy text here before launch.
 * The V3 build does not invent legal copy.
 */
export function LegalPage({ title }: { title: string }) {
  return (
    <>
      <PageHero title={<>{title}</>} />
      <section className="section">
        <div className="container prose">
          <p>This policy is being carried over from the previous version of our website.</p>
          <p>For any questions in the meantime, contact <a className="text-link" href={`mailto:${site.email}`}>{site.email}</a>.</p>
        </div>
      </section>
    </>
  );
}
