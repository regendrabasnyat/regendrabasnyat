/* eslint-disable @next/next/no-img-element */
/**
 * Decimal Tech logo — derived from the brand files in Decimal Tech/Logos
 * (Logo-Decimal-Tech.png): transparent mark + wordmark, with a light-text
 * wordmark variant for dark backgrounds.
 */
export function LogoMark({ className = "brand__mark" }: { className?: string }) {
  return <img src="/brand/decimal-mark.png" alt="" className={className} width={28} height={28} />;
}

/** Nav lockup — swaps wordmark colour with the theme. `onDark` forces the dark-background version. */
export function Brand({ onDark = false }: { onDark?: boolean }) {
  return (
    <span className="brand">
      <LogoMark />
      {onDark ? (
        <img src="/brand/decimal-wordmark-dark.png" alt="Decimal Tech" className="brand__word" width={150} height={17} />
      ) : (
        <>
          <img src="/brand/decimal-wordmark-light.png" alt="Decimal Tech" className="brand__word on-light" width={150} height={17} />
          <img src="/brand/decimal-wordmark-dark.png" alt="" aria-hidden="true" className="brand__word on-dark" width={150} height={17} />
        </>
      )}
    </span>
  );
}
