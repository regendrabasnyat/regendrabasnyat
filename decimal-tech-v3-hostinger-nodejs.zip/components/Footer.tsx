import Link from "next/link";
import { site, offices, bookingHref, bookingIsExternal } from "@/lib/site";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer__grid">
          <div className="footer__brand">
            <Link href="/" aria-label="Decimal Tech — home">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/brand/decimal-logo-dark.png" alt="Decimal Tech — the point of innovation" className="footer__logo" width={180} height={130} />
            </Link>
            <p className="footer__line">Top-tier engineers. Built around your work. Embedded engineering teams for companies that need experienced people who can ship.</p>
          </div>
          <nav aria-label="Company">
            <h2>Company</h2>
            <ul>
              <li><Link href="/teams">Teams</Link></li>
              <li><Link href="/engineering">Engineering</Link></li>
              <li><Link href="/about">About</Link></li>
              <li><Link href="/insights">Insights</Link></li>
            </ul>
          </nav>
          <nav aria-label="Engage">
            <h2>Engage</h2>
            <ul>
              <li><Link href="/teams#embedded-engineer">Hire an Engineer</Link></li>
              <li><Link href="/teams#engineering-team">Build a Team</Link></li>
              <li><Link href="/teams#engineering-pod">Build a Pod</Link></li>
              <li><Link href="/about#our-story">Our story</Link></li>
              <li>
                {bookingIsExternal ? (
                  <a href={bookingHref} target="_blank" rel="noopener noreferrer">Book a 30-Minute Call</a>
                ) : (
                  <Link href={bookingHref}>Book a 30-Minute Call</Link>
                )}
              </li>
            </ul>
          </nav>
          <div>
            <h2>Contact</h2>
            <ul>
              <li><a href={`mailto:${site.email}`}>{site.email}</a></li>
              <li><a href={site.phoneHref}>{site.phone}</a></li>
              {offices.map((o) => (
                <li key={o.city} className="small" style={{ color: "#9da1ab" }}>{o.city}</li>
              ))}
            </ul>
          </div>
        </div>
        <p className="footer__word" aria-hidden="true">Decimal<span style={{ color: "var(--accent)" }}>.</span></p>
        <div className="footer__bottom">
          <span>© {year} Decimal Tech LLC · Decimal Tech Pvt. Ltd.</span>
          <span style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
            <Link href="/privacy">Privacy</Link>
            <Link href="/terms">Terms</Link>
            <Link href="/cookies">Cookies</Link>
          </span>
          <span className="mono">US · NEPAL · AUSTRALIA</span>
        </div>
      </div>
    </footer>
  );
}
