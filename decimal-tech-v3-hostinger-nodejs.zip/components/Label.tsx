export function Label({ idx, children, plain }: { idx?: string; children: React.ReactNode; plain?: boolean }) {
  return (
    <p className={`label${plain ? " label--plain" : ""}`}>
      {idx && <span className="label__idx">{idx}</span>}
      <span>{children}</span>
    </p>
  );
}
