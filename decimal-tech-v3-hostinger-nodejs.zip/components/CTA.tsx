import Link from "next/link";
import { Arrow } from "./Arrow";
import { bookingHref, bookingIsExternal } from "@/lib/site";

type Variant = "primary" | "ghost" | "light" | "ghost-light";

export function ButtonLink({
  href, children, variant = "primary", size, external,
}: { href: string; children: React.ReactNode; variant?: Variant; size?: "sm"; external?: boolean }) {
  const cls = `btn btn--${variant}${size ? " btn--sm" : ""}`;
  if (external) {
    return (
      <a className={cls} href={href} target="_blank" rel="noopener noreferrer">
        {children} <Arrow />
        <span className="sr-only"> (opens in a new tab)</span>
      </a>
    );
  }
  return (
    <Link className={cls} href={href}>
      {children} <Arrow />
    </Link>
  );
}

/** The preserved 30-minute call path. Uses NEXT_PUBLIC_BOOKING_URL if configured. */
export function BookCall({ variant = "ghost", label = "Book a 30-Minute Conversation" }: { variant?: Variant; label?: string }) {
  return (
    <ButtonLink href={bookingHref} variant={variant} external={bookingIsExternal}>
      {label}
    </ButtonLink>
  );
}
