import { capabilities } from "@/lib/content";

const glyph: Record<string, React.ReactNode> = {
  streaming: (
    <svg viewBox="0 0 64 40" fill="none" aria-hidden="true">
      <path d="M2 20c6-14 10 14 16 0s10 10 15-4 10 14 15 4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      <circle cx="48" cy="24" r="2.6" className="hl" fill="currentColor" />
    </svg>
  ),
  saas: (
    <svg viewBox="0 0 64 40" fill="none" aria-hidden="true">
      <rect x="2" y="4" width="40" height="32" rx="3" stroke="currentColor" strokeWidth="1.4" />
      <path d="M2 12h40" stroke="currentColor" strokeWidth="1.4" />
      <rect x="48" y="10" width="14" height="26" rx="2.5" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="7" cy="8" r="1.4" className="hl" fill="currentColor" />
    </svg>
  ),
  marketplace: (
    <svg viewBox="0 0 64 40" fill="none" aria-hidden="true">
      <circle cx="12" cy="20" r="7" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="52" cy="20" r="7" stroke="currentColor" strokeWidth="1.4" />
      <path d="M21 15h22m0 0-4-4m4 4-4 4M43 25H21m0 0 4-4m-4 4 4 4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="32" cy="20" r="2" className="hl" fill="currentColor" />
    </svg>
  ),
  enterprise: (
    <svg viewBox="0 0 64 40" fill="none" aria-hidden="true">
      <path d="M8 36V12l12-6 12 6v24" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <path d="M32 36V18h24v18M38 24h4M46 24h4M38 30h4M46 30h4M14 18h4M14 26h4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      <circle cx="20" cy="12" r="2" className="hl" fill="currentColor" />
    </svg>
  ),
  cloud: (
    <svg viewBox="0 0 64 40" fill="none" aria-hidden="true">
      <circle cx="32" cy="10" r="5" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="12" cy="30" r="5" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="32" cy="30" r="5" className="hl" fill="currentColor" />
      <circle cx="52" cy="30" r="5" stroke="currentColor" strokeWidth="1.4" />
      <path d="M32 15v10M28.5 13.5 15 26.5M35.5 13.5 49 26.5" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  ),
};

export function Capabilities() {
  return (
    <section className="section" id="capabilities" aria-labelledby="cap-title">
      <div className="container">
        <div className="section-head section-head--split">
          <h2 id="cap-title" className="h2">Where our engineers have worked</h2>
          <p className="lead">Not a list of logos — the kinds of systems our people have built and run.</p>
        </div>

        <ul className="caps">
          {capabilities.map((c) => (
            <li key={c.id} className="caps__item">
              <span className="caps__glyph">{glyph[c.id]}</span>
              <div>
                <h3 className="caps__title">{c.title}</h3>
                <p className="body">{c.body}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
