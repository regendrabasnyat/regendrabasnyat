import { ButtonLink } from "../CTA";
import { engagementModels } from "@/lib/content";

const glyph = (id: string) => {
  if (id === "embedded-engineer") return <><i className="pt" /><i /><i /><i /></>;
  if (id === "engineering-team") return <><i className="team" /><i className="team" /><i className="team" /><i /></>;
  return <><i className="team" /><i className="team" /><i className="team" /><i className="team" /><i className="team" /></>;
};

export function EngagementModels({ headingLevel = 2 }: { headingLevel?: 1 | 2 }) {
  const H = headingLevel === 1 ? "h1" : "h2";
  return (
    <section className="section section--paper2" id="engagement" aria-labelledby="em-title">
      <div className="container">
        <div className="section-head section-head--split">
          <div>
            <H id="em-title" className="h2">
              One engineer.<br />A team.<br /><span className="muted">A pod.</span>
            </H>
          </div>
          <p className="lead">Start with one great engineer. Scale into a team when the work requires it.</p>
        </div>
        <ul className="models">
          {engagementModels.map((m, i) => (
            <li key={m.id} id={m.id} className={`model-card${m.featured ? " model-card--lead" : ""}`}>
              <div className="model-card__glyph" aria-hidden="true">{glyph(m.id)}</div>
              <div>
                <h3 className="model-card__title">{m.title}</h3>
                <p className="body" style={{ marginTop: 12 }}>{m.body}</p>
              </div>
              <div className="model-card__best">
                <p className="model-card__lbl">Best for</p>
                <ul style={{ display: "grid", gap: 8 }}>
                  {m.bestFor.map((b) => <li key={b}>{b}</li>)}
                </ul>
              </div>
              <ButtonLink href={`/contact?model=${m.id}`} variant={m.featured ? "light" : "primary"}>{m.cta}</ButtonLink>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
