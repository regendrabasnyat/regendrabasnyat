import { principles, dontDo } from "@/lib/content";

export function WhyDecimal() {
  return (
    <section className="section section--rule" id="why" aria-labelledby="why-title">
      <div className="container">
        <div className="section-head">
          <h2 id="why-title" className="h2">
            Small enough to care.<br /><span className="muted">Experienced enough to own it.</span>
          </h2>
        </div>
        <ol className="principles">
          {principles.map((p, i) => (
            <li key={p.title} className="principle">
              <span className="principle__n">0{i + 1}</span>
              <h3 className="principle__t">{p.title}</h3>
              <p className="principle__b">{p.body}</p>
            </li>
          ))}
        </ol>

        <div className="dont">
          <div>
            <h3 className="h2" style={{ marginTop: 20, fontSize: "clamp(2rem, 4vw, 3.5rem)" }}>Not a developer marketplace.</h3>
            <div className="dont__prefer">
              <p className="mono dim" style={{ marginBottom: 8 }}>We prefer</p>
              <span>Fewer people.</span>
              <span>Better engineers.</span>
              <span>Clear ownership<span className="dot">.</span></span>
            </div>
          </div>
          <div>
            <p className="mono dim">We don&apos;t</p>
            <ul className="dont__list" style={{ marginTop: 8 }}>
              {dontDo.map((d) => <li key={d}>{d}</li>)}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
