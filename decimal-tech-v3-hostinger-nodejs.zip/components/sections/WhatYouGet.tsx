import { whatYouGet } from "@/lib/content";

const mark: Record<string, React.ReactNode> = {
  vetted: (
    <svg viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <path d="M20 4 34 9v12c0 8-6 13.5-14 15-8-1.5-14-7-14-15V9Z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <path d="m14 20 4.5 4.5L27 16" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" className="hl" />
    </svg>
  ),
  "team-ready": (
    <svg viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <circle cx="11" cy="14" r="4.5" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="25" cy="14" r="4.5" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="18" cy="27" r="4.5" className="hl" fill="currentColor" />
      <path d="M11 18.5v2a4 4 0 0 0 4 4M25 18.5v2a4 4 0 0 1-4 4" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  ),
  experienced: (
    <svg viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <path d="M5 30V22M13 30V15M21 30V19M29 30V8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <circle cx="29" cy="8" r="2.6" className="hl" fill="currentColor" />
    </svg>
  ),
  "ai-native": (
    <svg viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <rect x="6" y="6" width="28" height="28" rx="4" stroke="currentColor" strokeWidth="1.4" strokeDasharray="3 3" />
      <path d="M14 20h12M20 14v12" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      <circle cx="20" cy="20" r="3" className="hl" fill="currentColor" />
    </svg>
  ),
  judgment: (
    <svg viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <path d="M20 6v26M8 14h24" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M8 14 4 24h8ZM32 14l-4 10h8Z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <circle cx="20" cy="33" r="2.4" className="hl" fill="currentColor" />
    </svg>
  ),
};

export function WhatYouGet() {
  return (
    <section className="section section--paper2" id="what-you-get" aria-labelledby="wyg-title">
      <div className="container">
        <div className="section-head section-head--split">
          <h2 id="wyg-title" className="h2">What you get</h2>
          <p className="lead">We find them. We vet them. You meet them. They join your team.</p>
        </div>

        <ul className="get">
          {whatYouGet.map((g) => (
            <li key={g.id} className="get__item">
              <span className="get__mark">{mark[g.id]}</span>
              <h3 className="get__title">{g.title}</h3>
              <p className="body">{g.body}</p>
            </li>
          ))}
        </ul>

        <p className="get__close">
          You don&apos;t get a pile of CVs.<br />
          <span>You get an engineer worth meeting<span className="dot">.</span></span>
        </p>
      </div>
    </section>
  );
}
