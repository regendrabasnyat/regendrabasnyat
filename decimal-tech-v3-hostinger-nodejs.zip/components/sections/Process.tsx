import { processSteps } from "@/lib/content";

/** Candidates narrowing to one. Stage x-positions match the label columns below. */
function Funnel() {
  const stages = [
    { n: 18, spread: 104, scatter: 34 },
    { n: 11, spread: 74, scatter: 26 },
    { n: 6, spread: 44, scatter: 18 },
    { n: 2, spread: 20, scatter: 8 },
    { n: 1, spread: 0, scatter: 0 },
  ];
  const W = 1200, H = 236, mid = H / 2, col = 240, x0 = 34;
  return (
    <svg className="funnel" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet" role="img"
      aria-label="A field of candidates narrowing stage by stage down to the one engineer who joins your team">
      <line x1="0" y1={mid} x2={W} y2={mid} stroke="currentColor" strokeOpacity="0.1" strokeWidth="1" />
      {stages.map((s, si) => {
        const cx = x0 + si * col;
        const last = si === stages.length - 1;
        return (
          <g key={si}>
            {Array.from({ length: s.n }).map((_, k) => {
              const t = s.n === 1 ? 0 : (k / (s.n - 1) - 0.5) * 2;
              const y = mid + t * s.spread;
              const dx = s.scatter === 0 ? 0 : (((k * 53) % 21) / 20 - 0.5) * 2 * s.scatter;
              const size = last ? 18 : si === 3 ? 12 : 9;
              return (
                <rect key={k} x={cx + dx} y={y - size / 2} width={size} height={size} rx="2"
                  fill={last ? "var(--accent)" : "currentColor"}
                  fillOpacity={last ? 1 : si === 3 ? 0.6 : 0.2 + si * 0.07} />
              );
            })}
            <line x1={cx + 4} y1={H - 22} x2={cx + 4} y2={H - 8} stroke="currentColor" strokeOpacity="0.25" strokeWidth="1" />
          </g>
        );
      })}
    </svg>
  );
}

export function Process() {
  return (
    <section className="section" id="process" aria-labelledby="process-title">
      <div className="container">
        <div className="section-head section-head--split">
          <h2 id="process-title" className="h2">
            How you end up<br /><span className="muted">with the right engineer.</span>
          </h2>
          <p className="lead">Five steps. Four of them are ours. You spend your time on the one that matters.</p>
        </div>

        <div className="process">
          <div className="process__chart" aria-hidden="false">
            <Funnel />
          </div>

          <ol className="process__steps">
            {processSteps.map((s, i) => (
              <li key={s.title} className={`process__step${i === 3 ? " process__step--yours" : ""}`}>
                <span className="process__n mono">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="process__title">{s.title}</h3>
                <p className="body">{s.body}</p>
                {i === 3 && <span className="process__who">Your call</span>}
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
