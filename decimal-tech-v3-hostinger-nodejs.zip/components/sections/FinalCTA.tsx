import { ButtonLink } from "../CTA";

export function FinalCTA() {
  return (
    <section className="section--night cta" aria-labelledby="cta-title">
      <div className="container">
        <h2 id="cta-title" className="cta__title">
          Have the work.<br />Need the engineer<span className="dot">?</span>
        </h2>
        <div className="cta__grid">
          <div className="lead" style={{ color: "#c9ccd3", maxWidth: "46ch" }}>
            <p>Tell us what your team needs. We&apos;ll help you find the right engineer.</p>
          </div>
          <div className="btn-row">
            <ButtonLink href="/contact" variant="light">Hire a Top-Tier Engineer</ButtonLink>
            <ButtonLink href="/teams" variant="ghost-light">Build Your Team</ButtonLink>
          </div>
        </div>
        <p className="cta__stamp">We&apos;re ready for the work<span className="dot">.</span></p>
      </div>
    </section>
  );
}
