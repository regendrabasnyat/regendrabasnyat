import { philosophy } from "@/lib/content";

export function Philosophy() {
  return (
    <section className="section section--night" id="philosophy" aria-labelledby="phil-title">
      <div className="container">
        <div className="section-head">
          <h2 id="phil-title" className="h2" style={{ maxWidth: "18ch" }}>
            AI gives engineers leverage.<br />
            <span className="muted">Experience gives them judgment.</span>
          </h2>
        </div>

        <div className="equation">
          {philosophy.parts.map((p, i) => (
            <div key={p.title} className="equation__part">
              {i > 0 && <span className="equation__op" aria-hidden="true">+</span>}
              <div className="equation__tile">
                <h3 className="equation__title">{p.title}</h3>
                <p>{p.body}</p>
              </div>
            </div>
          ))}
          <div className="equation__part equation__part--result">
            <span className="equation__op" aria-hidden="true">=</span>
            <div className="equation__tile equation__tile--result">
              <p className="equation__result">{philosophy.result}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
