import { problemChain } from "@/lib/content";

export function Problem() {
  return (
    <section className="section section--rule" aria-labelledby="problem-title">
      <div className="container">
        <div className="problem__grid">
          <div>
            <h2 id="problem-title" className="h2">
              You don&apos;t need more CVs.<br />
              <span className="muted">You need the right engineer.</span>
            </h2>
          </div>
          <div className="problem__copy">
            <p className="lead">You already know what needs to be built. Finding the right engineer is the hard part.</p>
            <p className="body">
              Sourcing, screening, technical interviews, filtering, hiring, onboarding — a full hiring pipeline, run
              alongside the product you&apos;re already trying to ship.
            </p>
          </div>
        </div>

        <ol className="chain" aria-label="What hiring an engineer normally takes">
          {problemChain.map((step) => (
            <li key={step} className="chain__link">{step}</li>
          ))}
        </ol>

        <p className="problem__answer">
          We do the filtering <em>before</em> you meet the engineer<span className="dot">.</span>
        </p>
      </div>
    </section>
  );
}
