"use client";
import { useEffect, useState } from "react";
import { offices } from "@/lib/site";

function useClock(tz: string) {
  const [t, setT] = useState<string>("--:--");
  useEffect(() => {
    const f = new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: tz });
    const tick = () => setT(f.format(new Date()));
    tick();
    const id = setInterval(tick, 30_000);
    return () => clearInterval(id);
  }, [tz]);
  return t;
}

function Office({ o }: { o: (typeof offices)[number] }) {
  const time = useClock(o.tz);
  return (
    <li className="office">
      <p className="mono dim">{o.region}</p>
      <h3 className="office__city">{o.city}</h3>
      <p className="mono">{o.role}{o.entity ? ` · ${o.entity}` : ""}</p>
      {o.address && <p className="small muted">{o.address}</p>}
      <p className="office__time"><span className="sr-only">Local time in {o.city}: </span>{time} local</p>
    </li>
  );
}

export function GlobalPresence() {
  return (
    <section className="section section--paper2" id="global" aria-labelledby="global-title">
      <div className="container">
        <div className="section-head section-head--split">
          <div>
            <h2 id="global-title" className="h2">US. Nepal.<br />Australia<span className="dot">.</span></h2>
          </div>
          <p className="lead">US headquarters and client coordination. An engineering centre in Kathmandu. A presence in Australia. Working hours that overlap with yours.</p>
        </div>
        <ul className="offices">
          {offices.map((o) => <Office key={o.city} o={o} />)}
        </ul>
      </div>
    </section>
  );
}
