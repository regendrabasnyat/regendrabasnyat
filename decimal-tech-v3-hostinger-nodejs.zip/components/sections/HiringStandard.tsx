import { ButtonLink } from "../CTA";
import { hiringPrinciples } from "@/lib/content";

export function HiringStandard() {
  return (
    <section className="section" id="our-standard" aria-labelledby="standard-title">
      <div className="container">
        <div className="section-head">
          <h2 id="standard-title" className="h2" style={{ fontSize: "clamp(1.9rem, 3.8vw, 3.25rem)", maxWidth: "20ch" }}>
            The company started with four people.<br />
            <span className="muted">The standard started with one question.</span>
          </h2>
        </div>

        <div className="standard__q">
          <p className="standard__question">Would we put this engineer on our own team<span className="dot">?</span></p>
          <p className="lead">If the answer isn&apos;t an unequivocal yes, they don&apos;t join Decimal.</p>
        </div>

        <ol className="principles" style={{ marginTop: "clamp(56px, 7vw, 88px)" }}>
          {hiringPrinciples.map((p, i) => (
            <li key={p.title} className="principle">
              <span className="principle__n">0{i + 1}</span>
              <h3 className="principle__t">{p.title}</h3>
              <p className="principle__b">{p.body}</p>
            </li>
          ))}
        </ol>

        <div className="standard__close">
          <p className="standard__line">We don&apos;t hire for volume.<br /><span className="muted">We hire for the standard.</span></p>
          <ButtonLink href="/contact">Hire a Top-Tier Engineer</ButtonLink>
        </div>
      </div>
    </section>
  );
}
