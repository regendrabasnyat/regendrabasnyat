import { proof } from "@/lib/content";

export function Proof() {
  return (
    <section className="section section--rule" id="proof" aria-labelledby="proof-title">
      <div className="container proof">
        <div>
          <h2 id="proof-title" className="h2" style={{ fontSize: "clamp(1.9rem, 3.8vw, 3.25rem)" }}>
            {proof.headline}
          </h2>
          <p className="proof__stamp">{proof.stamp}</p>
        </div>
        <div className="proof__body">
          {proof.body.map((b) => <p key={b} className="lead" style={{ maxWidth: "52ch" }}>{b}</p>)}
        </div>
      </div>
    </section>
  );
}
