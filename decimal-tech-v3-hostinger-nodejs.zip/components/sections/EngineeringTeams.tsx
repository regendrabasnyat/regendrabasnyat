import { teamOfferings } from "@/lib/content";

const glyphs: Record<string, React.ReactNode> = {
  embedded: (
    <svg viewBox="0 0 56 40" className="offer__glyph" aria-hidden="true" fill="none">
      <circle cx="8" cy="20" r="5" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="22" cy="20" r="5" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="36" cy="20" r="5" className="hl" fill="currentColor" />
      <circle cx="50" cy="20" r="5" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  ),
  pods: (
    <svg viewBox="0 0 56 40" className="offer__glyph" aria-hidden="true" fill="none">
      <rect x="1" y="4" width="36" height="32" rx="4" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 3" />
      <circle cx="12" cy="14" r="4.5" className="hl" fill="currentColor" />
      <circle cx="26" cy="14" r="4.5" className="hl" fill="currentColor" />
      <circle cx="19" cy="27" r="4.5" className="hl" fill="currentColor" />
      <circle cx="49" cy="20" r="5" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  ),
  dedicated: (
    <svg viewBox="0 0 56 40" className="offer__glyph" aria-hidden="true">
      {[0, 1, 2].map((r) => [0, 1, 2, 3].map((c) => (
        <circle key={`${r}${c}`} cx={7 + c * 14} cy={8 + r * 12} r={4} className={r === 1 && c === 1 ? "hl" : ""} fill="currentColor" />
      )))}
    </svg>
  ),
  leadership: (
    <svg viewBox="0 0 56 40" className="offer__glyph" aria-hidden="true" fill="none">
      <circle cx="28" cy="7" r="5" className="hl" fill="currentColor" />
      <path d="M28 12v6M10 24v-6h36v6M28 18v6" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="10" cy="31" r="5" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="28" cy="31" r="5" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="46" cy="31" r="5" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  ),
};

export function EngineeringTeams() {
  return (
    <section className="section section--rule" id="teams" aria-labelledby="teams-title">
      <div className="container">
        <div className="teams__intro">
          <div>
            <h2 id="teams-title" className="h2">Engineering teams</h2>
            <p className="lead">Add engineering capacity without building the team from scratch.</p>
          </div>
          <div className="body" style={{ display: "grid", gap: 16, alignSelf: "end" }}>
            <p>We provide experienced engineers who work directly inside your product organization.</p>
            <p>They use your repositories, tools, workflows and communication channels.</p>
            <p>They don&apos;t operate like an outsourced ticket factory.</p>
          </div>
        </div>
        <p className="statement">
          <em>You don&apos;t get a CV.</em> You get an engineer<span className="dot">.</span>
        </p>
        <ul className="offer-grid">
          {teamOfferings.map((o, i) => (
            <li key={o.id} className="offer">
              <span className="mono dim">0{i + 1}</span>
              {glyphs[o.id]}
              <div>
                <h3 className="h3 offer__title">{o.title}</h3>
                <p className="body" style={{ marginTop: 10 }}>{o.body}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
