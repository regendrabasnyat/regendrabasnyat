import { Portrait } from "../Portrait";
import { engineers } from "@/lib/content";
import { photoFor } from "@/lib/photos";

export function Engineers() {
  return (
    <section className="section" id="team" aria-labelledby="eng-title">
      <div className="container">
        <div className="section-head section-head--split">
          <div>
            <h2 id="eng-title" className="h2">The engineers</h2>
          </div>
          <p className="lead">Real engineers. Real ownership. The people who write, review and ship the code — not a bench behind an account manager.</p>
        </div>
        <ul className="engineers" aria-label="Decimal engineers" tabIndex={0}>
          {engineers.map((e, i) => (
            <li key={e.name} className={`person${e.lead ? " person--lead" : ""}`}>
              <Portrait name={e.name} src={photoFor(e.name)} />
              <div>
                <h3 className="person__name">{e.name}</h3>
                <p className="person__role mono dim">{e.role}</p>
                <p className="person__body">{e.body}</p>
                <ul className="chips" aria-label={`${e.name}'s focus areas`}>
                  {e.focus.map((f) => <li key={f} className="chip">{f}</li>)}
                </ul>
              </div>
            </li>
          ))}
        </ul>
        <p className="swipe-hint mono dim" aria-hidden="true"><span>Swipe</span><span>→</span></p>
      </div>
    </section>
  );
}
