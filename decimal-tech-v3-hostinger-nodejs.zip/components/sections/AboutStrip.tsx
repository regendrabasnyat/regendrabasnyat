import Link from "next/link";
import { Arrow } from "../Arrow";
import { aboutUs } from "@/lib/content";

export function AboutStrip() {
  return (
    <section className="section section--paper2" id="about-strip" aria-labelledby="about-strip-title">
      <div className="container about-strip">
        <h2 id="about-strip-title" className="h2">{aboutUs.headline}</h2>
        <div className="about-strip__body">
          {aboutUs.body.map((b) => <p key={b} className="body">{b}</p>)}
          <p className="about-strip__stamp">{aboutUs.stamp}</p>
          <Link href="/about" className="text-link">More about us <Arrow /></Link>
        </div>
      </div>
    </section>
  );
}
