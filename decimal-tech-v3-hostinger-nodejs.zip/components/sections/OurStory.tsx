import { storyLead, storyTimeline, storyBelief, storyClose } from "@/lib/content";

export function OurStory() {
  return (
    <section className="section section--paper2" id="our-story" aria-labelledby="story-title">
      <div className="container">
        <div className="section-head section-head--split">
          <div>
            <h2 id="story-title" className="h2" style={{ fontSize: "clamp(2rem, 4.4vw, 3.75rem)" }}>
              Four friends.<br />Twenty years later.<br /><span className="muted">One company.</span>
            </h2>
          </div>
          <p className="lead">{storyLead}</p>
        </div>

        <ol className="story">
          {storyTimeline.map((t, i) => (
            <li key={t.when} className="story__step">
              <span className="story__when mono">{t.when}</span>
              <div className="story__body">
                <h3 className="story__title">{t.title}</h3>
                <p className="body">{t.body}</p>
              </div>
            </li>
          ))}
        </ol>

        <div className="story__belief">
          <blockquote><p>{storyBelief}</p></blockquote>
        </div>

        <div className="story__close">
          {storyClose.map((p) => <p key={p} className="body">{p}</p>)}
          <p className="story__sign">
            Four old friends, one shared standard, and exceptional engineering talent from Nepal<span className="dot">.</span>
          </p>
        </div>
      </div>
    </section>
  );
}
