"use client";
import { useId, useRef, useState } from "react";
import Link from "next/link";
import { Arrow } from "../Arrow";
import { bookingHref, bookingIsExternal } from "@/lib/site";

/** Engineer → Team → Pod. Engineer is the primary commercial entry point. */
const STEPS = [
  {
    id: "engineer",
    label: "Engineer",
    tagline: "Start with one great engineer.",
    detail: "One experienced engineer, embedded directly into your team.",
    roster: [{ role: "Senior Engineer", meta: "Embedded · owns delivery" }],
  },
  {
    id: "team",
    label: "Team",
    tagline: "Add the people you need.",
    detail: "Multiple engineers aligned around your product and roadmap.",
    roster: [
      { role: "Senior Engineer", meta: "Embedded · owns delivery" },
      { role: "Full-Stack Engineer", meta: "Feature delivery" },
      { role: "Full-Stack Engineer", meta: "Integrations · platform" },
    ],
  },
  {
    id: "pod",
    label: "Pod",
    tagline: "Build a complete engineering unit.",
    detail: "A dedicated engineering unit with the skills to own a larger scope.",
    roster: [
      { role: "Technical Lead", meta: "Architecture · direction" },
      { role: "Senior Engineer", meta: "Embedded · owns delivery" },
      { role: "Full-Stack Engineer", meta: "Feature delivery" },
      { role: "Full-Stack Engineer", meta: "Integrations · platform" },
    ],
  },
] as const;

type StepId = (typeof STEPS)[number]["id"];

/** Your product team, with Decimal capacity added to it — scales with the selector. */
const SLOTS = 4;

function CapacityPanel({ step }: { step: (typeof STEPS)[number] }) {
  const ghosts = Math.max(0, SLOTS - step.roster.length);
  return (
    <figure className="cap-panel" aria-hidden="true">
      <div className="cap-panel__head">
        <span className="mono dim">your product team</span>
        <span className="mono dim stack__live">shipping</span>
      </div>

      <div className="cap-panel__inhouse">
        <span className="cap-stack">
          <span className="cap-avatar" />
          <span className="cap-avatar" />
          <span className="cap-avatar" />
        </span>
        <span>
          <b>Your existing team</b>
          <span className="cap-meta">Roadmap · repos · standards</span>
        </span>
      </div>

      <p className="cap-panel__group mono">
        <span className="dot">+</span> Decimal capacity
      </p>
      <ul className="cap-panel__roster">
        {step.roster.map((r, i) => (
          <li key={r.role + i} style={{ ["--i" as string]: `${i * 45}ms` }}>
            <span className="cap-avatar cap-avatar--dt" />
            <span>
              <b>{r.role}</b>
              <span className="cap-meta">{r.meta}</span>
            </span>
          </li>
        ))}
        {Array.from({ length: ghosts }).map((_, i) => (
          <li key={`ghost-${i}`} className="cap-ghost">
            <span className="cap-avatar cap-avatar--ghost" />
            <span className="cap-meta">Capacity to add</span>
          </li>
        ))}
      </ul>

      <figcaption className="cap-panel__foot mono dim">
        <span>same repo · same tools · same standup</span>
        <span className="status-bars" aria-hidden="true"><i /><i /><i /><i /></span>
      </figcaption>
    </figure>
  );
}

export function Hero() {
  const [active, setActive] = useState<StepId>("engineer");
  const uid = useId();
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);
  const step = STEPS.find((s) => s.id === active) ?? STEPS[0];

  const onKeyDown = (e: React.KeyboardEvent, i: number) => {
    const map: Record<string, number> = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: STEPS.length - 1 };
    const next = map[e.key];
    if (next === undefined) return;
    e.preventDefault();
    const idx = (next + STEPS.length) % STEPS.length;
    setActive(STEPS[idx].id);
    tabs.current[idx]?.focus();
  };

  return (
    <section className="hero" aria-labelledby="hero-title">
      <div className="container hero__grid">
        <div className="hero__main">
          <p className="hero__eyebrow">Engineering capacity, without the hiring friction</p>

          <h1 id="hero-title" className="display hero__title">
            <span className="line"><span>Top-tier engineers.</span></span>
            <span className="line"><span>Built around your work<span className="dot">.</span></span></span>
          </h1>

          <p className="hero__sub" data-reveal>
            Hire an experienced engineer who can plug into your team, understand the work, and ship — then build the
            team around them when you need more.
          </p>

          <div className="cap" data-reveal>
            <div className="cap__tabs" role="tablist" aria-label="Start with an engineer, then scale to a team or a pod">
              {STEPS.map((s, i) => (
                <div className="cap__seg" key={s.id}>
                  {i > 0 && <span className="cap__arrow" aria-hidden="true">→</span>}
                  <button
                    ref={(el) => { tabs.current[i] = el; }}
                    type="button"
                    role="tab"
                    id={`${uid}-tab-${s.id}`}
                    aria-selected={active === s.id}
                    aria-controls={`${uid}-panel`}
                    tabIndex={active === s.id ? 0 : -1}
                    className="cap__tab"
                    onClick={() => setActive(s.id)}
                    onKeyDown={(e) => onKeyDown(e, i)}
                  >
                    {s.label}
                  </button>
                </div>
              ))}
            </div>
            <div className="cap__panel" id={`${uid}-panel`} role="tabpanel" aria-labelledby={`${uid}-tab-${active}`} tabIndex={0}>
              <p className="cap__tagline">{step.tagline}</p>
              <p className="cap__detail">{step.detail}</p>
            </div>
          </div>

          <div className="btn-row hero__cta" data-reveal>
            {bookingIsExternal ? (
              <a className="btn btn--primary btn--lg" href={bookingHref} target="_blank" rel="noopener noreferrer">
                Hire a Top-Tier Engineer <Arrow />
                <span className="sr-only"> (opens in a new tab)</span>
              </a>
            ) : (
              <Link className="btn btn--primary btn--lg" href={bookingHref}>
                Hire a Top-Tier Engineer <Arrow />
              </Link>
            )}
            <Link className="btn btn--quiet" href="/contact">
              Build Your Team <Arrow />
            </Link>
          </div>

          <p className="hero__trust">
            Experienced engineers. Product-minded. AI-native. Built to work inside serious teams.
          </p>
        </div>

        <div className="hero__visual" data-reveal style={{ ["--d" as string]: "180ms" }}>
          <CapacityPanel step={step} />
        </div>
      </div>

      <div className="container">
        <p className="hero__regions">
          <span className="mono">US · NEPAL · AUSTRALIA</span>
          <span className="hero__proof">
            From one engineer to an entire engineering team — without rebuilding your hiring process.
          </span>
        </p>
      </div>
    </section>
  );
}
