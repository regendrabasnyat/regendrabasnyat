import { techStack, techStackIntro, techStackOutro } from "@/lib/content";

export function TechStack({ compact }: { compact?: boolean }) {
  return (
    <section className={`section${compact ? " section--tight section--rule" : ""}`} id="stack" aria-labelledby="stack-title">
      <div className="container">
        <div className="section-head section-head--split">
          <div>
            <h2 id="stack-title" className="h2">
              A senior stack<br /><span className="muted">for production systems.</span>
            </h2>
          </div>
          <p className="lead">{techStackIntro}</p>
        </div>
        <dl className="stack-table">
          {techStack.map((g, i) => (
            <div key={g.group} className={`stack-row${compact ? " stack-row--compact" : ""}`}>
              <dt className="stack-row__g">{g.group}</dt>
              <dd className="stack-row__items">
                {g.items.map((it) => <span key={it}>{it}</span>)}
              </dd>
            </div>
          ))}
        </dl>
        <p className="body" style={{ marginTop: 32 }}>{techStackOutro}</p>
      </div>
    </section>
  );
}
