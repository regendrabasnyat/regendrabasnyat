import { howItWorks } from "@/lib/content";

export function HowItWorks() {
  return (
    <section className="section" id="how-it-works" aria-labelledby="hiw-title">
      <div className="container">
        <div className="section-head section-head--split">
          <div>
            <h2 id="hiw-title" className="h2">From first call<br /><span className="muted">to shipping.</span></h2>
          </div>
          <p className="lead">You meet the engineers before they join. Once they do, they work in your repositories, your tools and your channels.</p>
        </div>
        <ol className="how">
          {howItWorks.map((s, i) => (
            <li key={s.title} className="how__step">
              <span className="how__n" aria-hidden="true">0{i + 1}</span>
              <h3 className="how__t">{s.title}</h3>
              <p className="body">{s.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
