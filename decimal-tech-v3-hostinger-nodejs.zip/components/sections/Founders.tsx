"use client";
import { useState } from "react";
import Link from "next/link";
import { Arrow } from "../Arrow";
import { Portrait } from "../Portrait";
import { founders } from "@/lib/content";
import { photoFor } from "@/lib/photos";

export function Founders({ storyLink = false }: { storyLink?: boolean }) {
  const [lead, ...rest] = founders;
  const [open, setOpen] = useState<string | null>(rest[0]?.name ?? null);

  return (
    <section className="section section--rule" id="founders" aria-labelledby="founders-title">
      <div className="container">
        <div className="section-head section-head--split">
          <div>
            <h2 id="founders-title" className="h2">Founder-led.<br /><span className="muted">Accountable by name.</span></h2>
          </div>
          <p className="lead">Four co-founders across engineering, operations, sales and staffing. You talk to the people responsible for the company.</p>
        </div>

        <div className="founders">
          <article className="founder-lead">
            <Portrait name={lead.name} src={photoFor(lead.name)} sizes="(min-width: 1000px) 40vw, 100vw" />
            <h3 className="founder-lead__name">{lead.name}</h3>
            <p className="founder-lead__role mono">{lead.role.toUpperCase()} <span className="dim">· {lead.short}</span></p>
            <div className="body" style={{ marginTop: 20, display: "grid", gap: 12 }}>
              {lead.story.map((p) => <p key={p}>{p}</p>)}
            </div>
            <ul className="chips" style={{ marginTop: 20 }}>
              {lead.strengths.map((s) => <li key={s} className="chip">{s}</li>)}
            </ul>
          </article>

          <ul className="founder-list">
            {rest.map((f) => {
              const isOpen = open === f.name;
              const pid = `founder-${f.name.toLowerCase()}`;
              return (
                <li key={f.name} className="founder">
                  <button type="button" className="founder__btn" aria-expanded={isOpen} aria-controls={pid} onClick={() => setOpen(isOpen ? null : f.name)}>
                    <span className="founder__name">{f.name}</span>
                    <span className="founder__meta">
                      <span className="mono">{f.role.replace("Co-Founder · ", "").toUpperCase()}</span>
                      <span className="mono dim">{f.short}</span>
                    </span>
                    <span className="founder__toggle" aria-hidden="true">
                      <svg width="14" height="14" viewBox="0 0 14 14"><path d="M7 1v12M1 7h12" stroke="currentColor" strokeWidth="1.5" /></svg>
                    </span>
                  </button>
                  <div id={pid} className="founder__panel" data-open={isOpen} role="region" aria-label={`About ${f.name}`} inert={!isOpen}>
                    <div>
                      <div className="founder__inner">
                        <Portrait name={f.name} src={photoFor(f.name)} sizes="160px" />
                        <div>
                          <p className="mono dim">{f.role} · {f.location}</p>
                          <div className="body" style={{ marginTop: 12 }}>
                            {f.story.map((p) => <p key={p}>{p}</p>)}
                          </div>
                          <ul className="chips" style={{ marginTop: 16 }}>
                            {f.strengths.map((s) => <li key={s} className="chip">{s}</li>)}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>

        {storyLink && (
          <p className="founders__story-link">
            <span className="h3">Four friends. Twenty years later. One company.</span>
            <Link href="/about#our-story" className="text-link">Read our story <Arrow /></Link>
          </p>
        )}
      </div>
    </section>
  );
}
