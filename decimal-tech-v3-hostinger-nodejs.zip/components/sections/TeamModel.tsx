import { teamModel } from "@/lib/content";

export function TeamModel() {
  return (
    <section className="section section--paper2" aria-labelledby="model-title">
      <div className="container">
        <div className="section-head section-head--split">
          <div>
            <h2 id="model-title" className="h2">
              Start with the work.<br /><span className="muted">Build the team around it.</span>
            </h2>
          </div>
          <p className="lead">We don&apos;t start from a bench of available people. We start from what you are building — and work backwards to the team that should own it.</p>
        </div>
        <ol className="model">
          {teamModel.map((q, i) => (
            <li key={q} className={`model__step${i >= 4 ? " model__step--final" : ""}`}>
              <span className="model__num" aria-hidden="true" />
              <span className="mono dim">0{i + 1}</span>
              <p className="model__q">{q}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
