"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { nav, site } from "@/lib/site";
import { Brand } from "./Logo";
import { Arrow } from "./Arrow";
import { ThemeToggle } from "./ThemeToggle";

export function Nav() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const btnRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        btnRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header className="nav" data-scrolled={scrolled || open}>
      <div className="container nav__inner">
        <Link href="/" aria-label={`${site.name} — home`}>
          <Brand />
        </Link>
        <nav aria-label="Primary" className="nav__links">
          {nav.map((l) => (
            <Link key={l.href} href={l.href} aria-current={pathname.startsWith(l.href) ? "page" : undefined}>
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="nav__right">
          <ThemeToggle />
          <Link href="/contact" className="btn btn--primary btn--sm">
            <span className="nav__cta-long">Hire a Top-Tier Engineer</span>
            <span className="nav__cta-short">Hire an Engineer</span>
            <Arrow />
          </Link>
          <button
            ref={btnRef}
            type="button"
            className="nav__menu-btn"
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? "Close" : "Menu"}
          </button>
        </div>
      </div>
      {open && (
        <div id="mobile-menu" className="mobile-menu">
          <nav aria-label="Mobile">
            <ul>
              {[{ href: "/", label: "Home" }, ...nav].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} aria-current={pathname === l.href ? "page" : undefined}>
                    {l.label} <Arrow />
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
          <div className="mobile-menu__foot">
            <div className="mobile-menu__row">
              <span className="mono dim">Theme</span>
              <ThemeToggle />
            </div>
            <Link href="/contact" className="btn btn--primary">
              Hire a Top-Tier Engineer <Arrow />
            </Link>
            <p className="mono dim">US · NEPAL · AUSTRALIA</p>
          </div>
        </div>
      )}
    </header>
  );
}
