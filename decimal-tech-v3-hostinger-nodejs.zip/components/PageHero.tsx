export function PageHero({ title, lead, children }: { title: React.ReactNode; lead?: string; children?: React.ReactNode }) {
  return (
    <section className="page-hero">
      <div className="container">
        <h1 className="display">{title}</h1>
        {lead && <p className="lead">{lead}</p>}
        {children && <div style={{ marginTop: 32 }}>{children}</div>}
      </div>
    </section>
  );
}
