import type { ComponentType } from "react";
import StaffAug from "./engineering-staff-augmentation-vs-outsourcing";

export const bodies: Record<string, ComponentType> = {
  "engineering-staff-augmentation-vs-outsourcing": StaffAug,
};
