import Link from "next/link";

/** Article body. Headings are phrased as the questions buyers (and AI answer engines) ask. */
export default function Body() {
  return (
    <>
      <h2 id="what-is-staff-augmentation">What is engineering staff augmentation?</h2>
      <p>
        <strong>Engineering staff augmentation is a way to add engineering capacity by bringing external engineers into your existing team.</strong>{" "}
        They work in your repositories, use your tools, join your stand-ups and follow your definition of done. Your product and engineering leadership decides what gets built; the augmented engineers help build it.
      </p>
      <p>
        The model exists because hiring is slow and uneven. Finding one strong engineer can take months. Assembling several who understand your product, communicate well and ship consistently takes longer. Augmentation shortens that path without asking you to hand your product to someone else.
      </p>

      <h2 id="vs-outsourcing">How is staff augmentation different from outsourcing?</h2>
      <p>
        <strong>The difference is ownership.</strong> With outsourcing, you define a scope and a vendor delivers it, managing its own team, process and priorities along the way. With staff augmentation, the engineers join <em>your</em> team and you keep control of priorities, architecture and product decisions.
      </p>
      <p>Neither is better in the abstract. They solve different problems:</p>
      <ul>
        <li><strong>Outsourcing</strong> suits a well-defined, separable project — a marketing site, an internal tool, a one-off migration — where you would rather buy an outcome than manage the work.</li>
        <li><strong>Staff augmentation</strong> suits ongoing product work, where requirements evolve weekly and the people writing the code need the same context as the people deciding what to build.</li>
      </ul>
      <p>
        A common failure pattern is using outsourcing for core product work. The vendor optimizes for the scope it was given; the product needs someone optimizing for the outcome. That gap shows up as rework, hand-off friction and code nobody on the internal team fully understands.
      </p>

      <h2 id="comparison">Staff augmentation vs. outsourcing vs. hiring</h2>
      <div className="table-wrap" role="region" aria-label="Comparison table" tabIndex={0}>
        <table>
          <thead>
            <tr>
              <th scope="col">Question</th>
              <th scope="col">Staff augmentation</th>
              <th scope="col">Outsourcing</th>
              <th scope="col">Full-time hiring</th>
            </tr>
          </thead>
          <tbody>
            <tr><th scope="row">Who owns product decisions?</th><td>You</td><td>Shared; vendor owns delivery</td><td>You</td></tr>
            <tr><th scope="row">Who manages day-to-day work?</th><td>Your leads</td><td>Vendor project manager</td><td>Your leads</td></tr>
            <tr><th scope="row">Where does the work happen?</th><td>Your repos, tools and channels</td><td>Often vendor systems, handed over</td><td>Your repos, tools and channels</td></tr>
            <tr><th scope="row">Speed to add capacity</th><td>Fast</td><td>Fast to start, slower to change scope</td><td>Slowest</td></tr>
            <tr><th scope="row">Flexibility to scale up or down</th><td>High</td><td>Tied to contract scope</td><td>Low</td></tr>
            <tr><th scope="row">Knowledge stays in your team?</th><td>Yes, if engineers are embedded</td><td>Only via hand-over</td><td>Yes</td></tr>
            <tr><th scope="row">Best for</th><td>Ongoing product work, capacity gaps</td><td>Defined, separable projects</td><td>Long-term core roles</td></tr>
          </tbody>
        </table>
      </div>
      <p>
        Most growing companies end up using a mix: a permanent core team, augmented engineers for capacity and specialist skills, and the occasional outsourced project for work that sits outside the product.
      </p>

      <h2 id="which-model">Should you add an embedded engineer, a pod or a dedicated team?</h2>
      <p>Start with the work, then size the team around it. Three shapes cover most situations:</p>
      <dl className="models-dl">
        <div>
          <dt>Embedded engineer</dt>
          <dd>One experienced engineer joins your existing team. Best for feature delivery, a backend or frontend capacity gap, or platform work your team can&apos;t get to.</dd>
        </div>
        <div>
          <dt>Engineering pod</dt>
          <dd>A small group assembled around one product area or roadmap theme. Best for a new module, a major feature or a platform expansion that needs several people working as a unit.</dd>
        </div>
        <div>
          <dt>Dedicated engineering team</dt>
          <dd>A larger capability operating as an extension of your organization. Best for scale-ups running multiple product streams or long-term product development.</dd>
        </div>
      </dl>
      <p>
        A useful rule: if you can name the product area and the person who will own it, you probably need a pod. If you can only name a backlog, start with one or two embedded engineers and grow from there.
      </p>

      <h2 id="integration">How do augmented engineers integrate into your team?</h2>
      <p>Integration is where augmentation succeeds or fails. The engineers should be indistinguishable from your own team in how they work:</p>
      <ol>
        <li><strong>Same repositories.</strong> They commit to your codebase and follow your branching and review conventions.</li>
        <li><strong>Same tools.</strong> Your issue tracker, CI/CD, observability and documentation — not a parallel set.</li>
        <li><strong>Same communication.</strong> They join your channels, stand-ups, planning and retros.</li>
        <li><strong>Same standards.</strong> The same code review bar and definition of done as everyone else.</li>
        <li><strong>Clear ownership.</strong> Each engineer or pod has a named area they are accountable for, not just a ticket queue.</li>
      </ol>
      <blockquote>
        <p>The test of a good embedded engineer is simple: after a few weeks, nobody on your team thinks of them as external.</p>
      </blockquote>

      <h2 id="ai">What changes with AI-native engineering?</h2>
      <p>
        AI coding and review tools have changed how much a single experienced engineer can do. Research, boilerplate, test generation, first-pass code review and documentation are all faster. What has not changed is the need for someone to make the important decisions: architecture, trade-offs, what to build next and what &quot;done&quot; really means.
      </p>
      <p>
        That shifts what you should look for in augmented engineers. Headcount matters less; judgment matters more. A smaller team of experienced engineers using AI well will usually outperform a larger team treating AI as a shortcut. At Decimal Tech we describe it as:{" "}
        <strong>AI gives engineers leverage. Engineers own the outcome.</strong>
      </p>

      <h2 id="evaluate">How do you evaluate a staff augmentation partner?</h2>
      <p>Ask questions that reveal how the partner thinks about ownership, not just availability:</p>
      <ul className="checklist">
        <li>Will I meet and interview the specific engineers before they join?</li>
        <li>Who is accountable if an engineer isn&apos;t working out — and how quickly is it addressed?</li>
        <li>Do your engineers work in our tools and channels, or through an account manager?</li>
        <li>How do you decide seniority and team shape for our work?</li>
        <li>How do your engineers use AI, and how do you keep quality high when they do?</li>
        <li>Can I talk to the founders or technical leadership directly?</li>
      </ul>
      <p>And watch for red flags:</p>
      <ul className="redflags">
        <li>A stack of CVs instead of a conversation about your product.</li>
        <li>Engineers hidden behind a project manager you must go through.</li>
        <li>Pressure to add headcount before the work is understood.</li>
        <li>Metrics that sound impressive but have no methodology behind them.</li>
      </ul>

      <h2 id="glossary">Glossary</h2>
      <dl className="glossary">
        <div><dt>Staff augmentation</dt><dd>Adding external engineers into your existing team, under your direction.</dd></div>
        <div><dt>Outsourcing</dt><dd>Contracting a vendor to deliver a defined scope, with the vendor managing the work.</dd></div>
        <div><dt>Embedded engineer</dt><dd>An external engineer who works inside your team&apos;s repos, tools and rituals as a full team member.</dd></div>
        <div><dt>Engineering pod</dt><dd>A small cross-functional group of engineers assembled around one product area.</dd></div>
        <div><dt>Dedicated engineering team</dt><dd>A larger external engineering capability operating as an extension of your organization.</dd></div>
        <div><dt>AI-native engineering</dt><dd>Using AI throughout research, implementation, testing, review and documentation, with engineers accountable for decisions.</dd></div>
      </dl>

      <aside className="post-about" aria-label="About Decimal Tech">
        <p className="label">About Decimal Tech</p>
        <p>
          Decimal Tech builds and embeds experienced engineering teams into companies that need more engineering capacity — from individual senior engineers to engineering pods and dedicated teams. Our engineers work directly inside client product organizations, using AI-native workflows. We have offices in the United States, Nepal and Australia.{" "}
          <Link href="/teams" className="text-link">See how our teams work</Link>
        </p>
      </aside>
    </>
  );
}
