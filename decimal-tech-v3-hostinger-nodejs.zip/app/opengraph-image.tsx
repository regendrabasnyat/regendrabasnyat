export const dynamic = "force-static";
import { ImageResponse } from "next/og";

export const alt = "Decimal Tech — Top-tier engineers. Built around your work.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OG() {
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", justifyContent: "space-between", background: "#f4f3ef", padding: 72, color: "#0a0b0d" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, fontSize: 28, letterSpacing: 4, fontWeight: 700 }}>
          <div style={{ width: 40, height: 40, borderRadius: 40, background: "#1c45c9", position: "relative", display: "flex" }}>
            <div style={{ position: "absolute", right: -8, top: -8, width: 20, height: 20, borderRadius: 20, background: "#ee3b24", border: "3px solid #f4f3ef" }} />
          </div>
          DECIMAL TECH
        </div>
        <div style={{ display: "flex", flexDirection: "column", fontSize: 96, fontWeight: 800, lineHeight: 0.92, letterSpacing: -4 }}>
          <span>TOP-TIER ENGINEERS.</span>
          <span>BUILT AROUND YOUR WORK<span style={{ color: "#ee3b24" }}>.</span></span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 24, color: "#62666f" }}>
          <span>Embedded engineers · Pods · Dedicated teams</span>
          <span>US · NEPAL · AUSTRALIA</span>
        </div>
      </div>
    ),
    size
  );
}
