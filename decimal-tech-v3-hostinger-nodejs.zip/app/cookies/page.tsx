import type { Metadata } from "next";
import { LegalPage } from "@/components/LegalPage";

export const metadata: Metadata = { title: "Cookie Policy", alternates: { canonical: "/cookies" } };
export default function Page() { return <LegalPage title="Cookie Policy" />; }
