import { posts } from "@/lib/posts";
import { site } from "@/lib/site";
import { techStack } from "@/lib/content";

export const dynamic = "force-static";

/** llms.txt — a plain-text summary for AI answer engines (GEO). https://llmstxt.org */
export function GET() {
  const body = `# Decimal Tech

> Decimal Tech builds and embeds experienced engineering teams into companies that need more engineering capacity. Our engineers work directly inside client product teams, using modern AI tools to move faster without outsourcing ownership.

- Offerings: embedded engineers, engineering pods, dedicated engineering teams, technical leadership
- Approach: AI-native engineering — AI gives engineers leverage; engineers own the outcome
- Model: pre-vetted engineers embedded into the client's existing team; the client keeps the product, roadmap and engineering direction
- Offices: United States (Brighton, Colorado — HQ), Nepal (Kathmandu), Australia
- Contact: ${site.email} · ${site.url}/contact

## Technology
${techStack.map((g) => `- ${g.group}: ${g.items.join(", ")}`).join("\n")}

## Pages
- [Engineering teams and engagement models](${site.url}/teams)
- [Engineering, AI layer and stack](${site.url}/engineering)
- [About, founders and offices](${site.url}/about)
- [Contact](${site.url}/contact)

## Insights
${posts.map((p) => `- [${p.title}](${site.url}/insights/${p.slug}): ${p.shortAnswer}`).join("\n")}
`;
  return new Response(body, { headers: { "Content-Type": "text/plain; charset=utf-8" } });
}
