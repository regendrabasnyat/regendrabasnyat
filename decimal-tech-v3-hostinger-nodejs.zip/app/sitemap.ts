export const dynamic = "force-static";
import type { MetadataRoute } from "next";
import { site } from "@/lib/site";
import { posts } from "@/lib/posts";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const routes: [string, number][] = [["", 1], ["/teams", 0.9], ["/engineering", 0.8], ["/about", 0.7], ["/insights", 0.6], ["/contact", 0.8], ["/privacy", 0.2], ["/terms", 0.2], ["/cookies", 0.2]];
  return [
    ...routes.map(([p, priority]) => ({ url: `${site.url}${p}`, lastModified: now, changeFrequency: "monthly" as const, priority })),
    ...posts.map((p) => ({ url: `${site.url}/insights/${p.slug}`, lastModified: new Date(p.updated), changeFrequency: "monthly" as const, priority: 0.7 })),
  ];
}
