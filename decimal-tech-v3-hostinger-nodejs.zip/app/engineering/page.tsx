import type { Metadata } from "next";
import { PageHero } from "@/components/PageHero";
import { Capabilities } from "@/components/sections/Capabilities";
import { TechStack } from "@/components/sections/TechStack";
import { Philosophy } from "@/components/sections/Philosophy";
import { Process } from "@/components/sections/Process";
import { Proof } from "@/components/sections/Proof";
import { FinalCTA } from "@/components/sections/FinalCTA";

export const metadata: Metadata = {
  title: "Engineering — Capabilities, Stack & How We Vet",
  description:
    "The systems our engineers have built, the stack they work in, how we vet them, and why experience still decides the outcome when AI does the repetitive work.",
  alternates: { canonical: "/engineering" },
};

export default function EngineeringPage() {
  return (
    <>
      <PageHero
        title={<>Engineers who have<br /><span className="muted">done this before.</span></>}
        lead="Streaming, SaaS, marketplaces, government systems and cloud platforms — and a vetting process that happens before you meet anyone."
      />
      <Capabilities />
      <TechStack />
      <Process />
      <Philosophy />
      <Proof />
      <FinalCTA />
    </>
  );
}
