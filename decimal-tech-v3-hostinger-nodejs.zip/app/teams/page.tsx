import type { Metadata } from "next";
import { PageHero } from "@/components/PageHero";
import { ButtonLink } from "@/components/CTA";
import { EngineeringTeams } from "@/components/sections/EngineeringTeams";
import { TeamModel } from "@/components/sections/TeamModel";
import { EngagementModels } from "@/components/sections/EngagementModels";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { WhyDecimal } from "@/components/sections/WhyDecimal";
import { FinalCTA } from "@/components/sections/FinalCTA";

export const metadata: Metadata = {
  title: "Engineering Teams — Embedded Engineers, Pods & Dedicated Teams",
  description: "Engineering staff augmentation done properly: embedded senior engineers, engineering pods and dedicated engineering teams that work inside your product organization.",
  alternates: { canonical: "/teams" },
};

export default function TeamsPage() {
  return (
    <>
      <PageHero
        title={<>Start with one engineer.<br /><span className="muted">Scale when the work does.</span></>}
        lead="Experienced engineers who integrate with your team, understand the work, and actually ship. Start with one — add more when the roadmap asks for it."
      >
        <ButtonLink href="/contact">Hire a Top-Tier Engineer</ButtonLink>
      </PageHero>
      <EngagementModels />
      <EngineeringTeams />
      <TeamModel />
      <HowItWorks />
      <WhyDecimal />
      <FinalCTA />
    </>
  );
}
