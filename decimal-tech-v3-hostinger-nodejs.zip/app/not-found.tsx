import { PageHero } from "@/components/PageHero";
import { ButtonLink } from "@/components/CTA";

export default function NotFound() {
  return (
    <PageHero title={<>Not found<span className="dot">.</span></>} lead="This page moved or never existed.">
      <ButtonLink href="/">Back to home</ButtonLink>
    </PageHero>
  );
}
