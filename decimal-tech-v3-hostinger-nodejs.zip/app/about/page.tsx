import type { Metadata } from "next";
import { PageHero } from "@/components/PageHero";
import { Founders } from "@/components/sections/Founders";
import { OurStory } from "@/components/sections/OurStory";
import { HiringStandard } from "@/components/sections/HiringStandard";
import { Engineers } from "@/components/sections/Engineers";
import { GlobalPresence } from "@/components/sections/GlobalPresence";
import { FinalCTA } from "@/components/sections/FinalCTA";

export const metadata: Metadata = {
  title: "About — Founders, Engineers & Offices",
  description: "Four childhood friends, one engineering standard. The story behind Decimal Tech, how we hire engineers, and where we work from — the US, Nepal and Australia.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <>
      <PageHero
        title={<>We&apos;re young.<br /><span className="muted">Our experience isn&apos;t.</span></>}
        lead="A small team with serious engineering experience. We've had the same hiring problem our clients have — so we built Decimal around solving it."
      />
      <Founders />
      <OurStory />
      <HiringStandard />
      <Engineers />
      <GlobalPresence />
      <FinalCTA />
    </>
  );
}
