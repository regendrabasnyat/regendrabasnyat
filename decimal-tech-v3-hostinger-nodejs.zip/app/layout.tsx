import type { Metadata, Viewport } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import "./globals.css";
import { Nav } from "@/components/Nav";
import { Footer } from "@/components/Footer";
import { Reveal } from "@/components/Reveal";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: site.title, template: "%s — Decimal Tech" },
  description: site.description,
  applicationName: "Decimal Tech",
  openGraph: {
    type: "website",
    siteName: "Decimal Tech",
    title: site.title,
    description: site.description,
    url: site.url,
    locale: "en_US",
  },
  twitter: { card: "summary_large_image", site: site.twitter, title: site.title, description: site.description },
  robots: { index: true, follow: true },
  alternates: { canonical: "/", types: { "application/rss+xml": "/insights/rss.xml" } },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f4f3ef" },
    { media: "(prefers-color-scheme: dark)", color: "#0f1013" },
  ],
  width: "device-width",
  initialScale: 1,
};

/** Runs before paint: enables reveal animations and applies the stored or system theme (no flash). */
const themeScript = `(function(){var d=document.documentElement;d.classList.add('js');var t=null;try{t=localStorage.getItem('theme')}catch(e){}var m=window.matchMedia('(prefers-color-scheme: dark)');d.dataset.theme=t||(m.matches?'dark':'light');if(!t&&m.addEventListener){m.addEventListener('change',function(e){try{if(localStorage.getItem('theme'))return}catch(_){}d.dataset.theme=e.matches?'dark':'light'})}})();`;

const orgJsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Decimal Tech",
  legalName: "Decimal Tech LLC",
  url: site.url,
  email: site.email,
  telephone: "+1-720-576-9024",
  logo: `${site.url}/brand/decimal-logo-light.png`,
  description: site.description,
  address: [
    { "@type": "PostalAddress", streetAddress: "2785 Black Hawk Pl", addressLocality: "Brighton", addressRegion: "CO", postalCode: "80601", addressCountry: "US" },
    { "@type": "PostalAddress", streetAddress: "Kalanki-14", addressLocality: "Kathmandu", addressCountry: "NP" },
  ],
  areaServed: ["US", "AU", "NP"],
  knowsAbout: ["Engineering staff augmentation", "Dedicated engineering teams", "Product engineering", "Streaming platform engineering", "AWS engineering", "AI-native software engineering"],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable}`} suppressHydrationWarning>
      <head>
        {/* Enables reveal animations only when JS runs; content is visible without it. */}
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(orgJsonLd) }} />
      </head>
      <body>
        <a href="#main" className="skip-link">Skip to content</a>
        <Nav />
        <main id="main">{children}</main>
        <Footer />
        <Reveal />
      </body>
    </html>
  );
}
