"use client";
import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { site } from "@/lib/site";
import { Arrow } from "@/components/Arrow";

const capacityOptions = [
  { v: "", l: "Select…" },
  { v: "embedded-engineer", l: "One experienced engineer" },
  { v: "engineering-team", l: "A team of engineers" },
  { v: "engineering-pod", l: "A complete engineering pod" },
  { v: "technical-leadership", l: "Technical leadership" },
  { v: "not-sure", l: "Not sure yet" },
];
const sizeOptions = ["", "Just founders", "1–5", "6–20", "21–50", "50+"];

type Status = { kind: "idle" | "sending" | "ok" | "err"; msg?: string };

export function ContactForm() {
  const params = useSearchParams();
  const preset = params.get("model") ?? "";
  const [status, setStatus] = useState<Status>({ kind: "idle" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries()) as Record<string, string>;
    const errs: Record<string, string> = {};
    if (!data.name?.trim()) errs.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email || "")) errs.email = "Please enter a valid work email.";
    if (!data.company?.trim()) errs.company = "Please enter your company.";
    if (!data.building?.trim()) errs.building = "Tell us briefly what you're building.";
    setErrors(errs);
    if (Object.keys(errs).length) {
      const first = form.querySelector<HTMLElement>(`[name="${Object.keys(errs)[0]}"]`);
      first?.focus();
      return;
    }
    setStatus({ kind: "sending" });
    try {
      const res = await fetch(process.env.NEXT_PUBLIC_CONTACT_ENDPOINT || "/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json.error || "Something went wrong.");
      setStatus({ kind: "ok", msg: "Thanks — we've got it. A founder will reply personally, usually within one business day." });
      form.reset();
    } catch (err) {
      setStatus({ kind: "err", msg: `${(err as Error).message} You can also email ${site.email}.` });
    }
  }

  const f = (name: string) => ({
    id: `f-${name}`, name,
    "aria-invalid": errors[name] ? true : undefined,
    "aria-describedby": errors[name] ? `f-${name}-err` : undefined,
  });
  const Err = ({ n }: { n: string }) => errors[n] ? <p id={`f-${n}-err`} className="field__err">{errors[n]}</p> : null;

  return (
    <form className="form" onSubmit={onSubmit} noValidate>
      <div className="form__row">
        <div className="field"><label htmlFor="f-name">Name</label><input {...f("name")} autoComplete="name" required /><Err n="name" /></div>
        <div className="field"><label htmlFor="f-email">Work email</label><input {...f("email")} type="email" autoComplete="email" required /><Err n="email" /></div>
      </div>
      <div className="field"><label htmlFor="f-company">Company</label><input {...f("company")} autoComplete="organization" required /><Err n="company" /></div>
      <div className="field"><label htmlFor="f-building">What are you building?</label><textarea {...f("building")} rows={3} required /><Err n="building" /></div>
      <div className="form__row">
        <div className="field">
          <label htmlFor="f-capacity">What engineering capacity do you need?</label>
          <select {...f("capacity")} defaultValue={capacityOptions.some((o) => o.v === preset) ? preset : ""}>
            {capacityOptions.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
          </select>
        </div>
        <div className="field">
          <label htmlFor="f-teamSize">Current engineering team size <span className="opt">(optional)</span></label>
          <select {...f("teamSize")} defaultValue="">
            {sizeOptions.map((o) => <option key={o} value={o}>{o || "Select…"}</option>)}
          </select>
        </div>
      </div>
      <div className="field"><label htmlFor="f-stack">Technology / stack <span className="opt">(optional)</span></label><input {...f("stack")} placeholder="e.g. TypeScript, Next.js, AWS" /></div>
      <div className="field"><label htmlFor="f-context">Additional context <span className="opt">(optional)</span></label><textarea {...f("context")} rows={4} /></div>
      <label className="check"><input type="checkbox" name="wantsCall" value="yes" /> I&apos;d like a 30-minute call</label>
      {/* Honeypot */}
      <div aria-hidden="true" style={{ position: "absolute", left: "-10000px" }}>
        <label htmlFor="f-website">Website</label><input id="f-website" name="website" tabIndex={-1} autoComplete="off" />
      </div>
      <div className="btn-row" style={{ alignItems: "center" }}>
        <button type="submit" className="btn btn--primary" disabled={status.kind === "sending"}>
          {status.kind === "sending" ? "Sending…" : "Start the Conversation"} <Arrow />
        </button>
        <a className="text-link" href="#book-strategy-call">Book a 30-Minute Call</a>
      </div>
      <div aria-live="polite" role="status">
        {(status.kind === "ok" || status.kind === "err") && (
          <p className={`form__status form__status--${status.kind}`}>{status.msg}</p>
        )}
      </div>
    </form>
  );
}
