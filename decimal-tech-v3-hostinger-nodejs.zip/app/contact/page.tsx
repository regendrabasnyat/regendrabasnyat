import type { Metadata } from "next";
import { Suspense } from "react";
import { PageHero } from "@/components/PageHero";
import { ContactForm } from "./ContactForm";
import { site, offices, bookingIsExternal, bookingHref } from "@/lib/site";
import { Arrow } from "@/components/Arrow";
import { CalendlyEmbed } from "@/components/CalendlyEmbed";

export const metadata: Metadata = {
  title: "Contact — Build Your Engineering Team",
  description: "Tell Decimal Tech what you're building and what engineering capacity you need. Or book a 30-minute conversation.",
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return (
    <>
      <PageHero
        title={<>Let&apos;s talk<br />about the work<span className="dot">.</span></>}
        lead="Tell us what you're building, where your team is stuck and what you need next. We'll tell you honestly whether Decimal is a fit."
      />
      <section className="section">
        <div className="container contact">
          <div>
            <h2 className="h3" style={{ marginBottom: 28 }}>Start the conversation</h2>
            <Suspense fallback={null}>
              <ContactForm />
            </Suspense>
          </div>
          <aside>
            <div className="aside-card">
              <p className="label">30 minutes</p>
              <h2 className="h3">Book a 30-minute call</h2>
              <p className="body">A direct conversation with a founder about your product, your roadmap and the engineering gap. No sales deck.</p>
              <a className="btn btn--primary" href="#book-strategy-call">Pick a time <Arrow /></a>
            </div>
            <div className="aside-card">
              <p className="label">Direct</p>
              <dl>
                <div><dt>Email</dt><dd><a className="text-link" href={`mailto:${site.email}`}>{site.email}</a></dd></div>
                <div><dt>US</dt><dd><a className="text-link" href={site.phoneHref}>{site.phone}</a></dd></div>
                <div><dt>WhatsApp</dt><dd><a className="text-link" href={site.whatsappHref} target="_blank" rel="noopener noreferrer">{site.whatsapp}</a></dd></div>
                {offices.filter((o) => o.address).map((o) => (
                  <div key={o.city}><dt>{o.region === "United States" ? "US HQ" : o.region}</dt><dd className="small">{o.entity}<br />{o.address}</dd></div>
                ))}
              </dl>
            </div>
          </aside>
        </div>
      </section>

      {/* Anchor preserved from V2: /contact#book-strategy-call */}
      <section className="section section--tight section--rule" id="book-strategy-call" aria-labelledby="book-title">
        <div className="container">
          <div className="section-head section-head--split">
            <div>
              <h2 id="book-title" className="h2" style={{ fontSize: "clamp(1.9rem, 3.6vw, 3rem)" }}>
                Thirty minutes.<br /><span className="muted">A founder, not a salesperson.</span>
              </h2>
            </div>
            <p className="lead">Pick a time that suits your time zone. Bring your roadmap, your stack and the gap you\'re trying to close.</p>
          </div>
          <CalendlyEmbed />
        </div>
      </section>
    </>
  );
}
