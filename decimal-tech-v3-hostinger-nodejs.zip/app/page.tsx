import { Hero } from "@/components/sections/Hero";
import { Problem } from "@/components/sections/Problem";
import { WhatYouGet } from "@/components/sections/WhatYouGet";
import { Process } from "@/components/sections/Process";
import { EngagementModels } from "@/components/sections/EngagementModels";
import { Philosophy } from "@/components/sections/Philosophy";
import { Capabilities } from "@/components/sections/Capabilities";
import { TechStack } from "@/components/sections/TechStack";
import { Proof } from "@/components/sections/Proof";
import { AboutStrip } from "@/components/sections/AboutStrip";
import { Founders } from "@/components/sections/Founders";
import { GlobalPresence } from "@/components/sections/GlobalPresence";
import { FinalCTA } from "@/components/sections/FinalCTA";

export default function Home() {
  return (
    <>
      <Hero />
      <Problem />
      <WhatYouGet />
      <Process />
      <EngagementModels />
      <Philosophy />
      <Capabilities />
      <TechStack compact />
      <Proof />
      <AboutStrip />
      <Founders storyLink />
      <GlobalPresence />
      <FinalCTA />
    </>
  );
}
