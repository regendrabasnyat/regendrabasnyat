import { posts } from "@/lib/posts";
import { site } from "@/lib/site";

export const dynamic = "force-static";

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export function GET() {
  const items = posts
    .map((p) => `<item><title>${esc(p.title)}</title><link>${site.url}/insights/${p.slug}</link><guid>${site.url}/insights/${p.slug}</guid><pubDate>${new Date(p.published + "T00:00:00Z").toUTCString()}</pubDate><description>${esc(p.description)}</description><category>${esc(p.category)}</category></item>`)
    .join("");
  const xml = `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>Decimal Tech — Insights</title><link>${site.url}/insights</link><description>Notes on engineering teams, staff augmentation and AI-native engineering.</description><language>en</language>${items}</channel></rss>`;
  return new Response(xml, { headers: { "Content-Type": "application/rss+xml; charset=utf-8" } });
}
