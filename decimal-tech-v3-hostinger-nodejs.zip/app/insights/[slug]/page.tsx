import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { posts, getPost, fmtDate } from "@/lib/posts";
import { bodies } from "@/content";
import { site } from "@/lib/site";
import { FinalCTA } from "@/components/sections/FinalCTA";

export const dynamicParams = false;
export function generateStaticParams() {
  return posts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) return {};
  const url = `/insights/${post.slug}`;
  return {
    title: { absolute: `${post.seoTitle} — Decimal Tech` },
    description: post.description,
    keywords: post.keywords,
    alternates: { canonical: url },
    authors: [{ name: "Decimal Tech", url: site.url }],
    openGraph: {
      type: "article", url, title: post.seoTitle, description: post.description,
      publishedTime: post.published, modifiedTime: post.updated, section: post.category, tags: post.keywords,
    },
    twitter: { card: "summary_large_image", title: post.seoTitle, description: post.description },
  };
}

export default async function PostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = getPost(slug);
  const Body = bodies[slug];
  if (!post || !Body) notFound();
  const url = `${site.url}/insights/${post.slug}`;

  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "BlogPosting",
        "@id": `${url}#article`,
        headline: post.title,
        description: post.description,
        abstract: post.shortAnswer,
        datePublished: post.published,
        dateModified: post.updated,
        inLanguage: "en",
        articleSection: post.category,
        keywords: post.keywords.join(", "),
        mainEntityOfPage: url,
        url,
        image: `${site.url}/opengraph-image`,
        author: { "@type": "Organization", name: "Decimal Tech", url: site.url },
        publisher: { "@type": "Organization", name: "Decimal Tech", url: site.url, logo: { "@type": "ImageObject", url: `${site.url}/brand/decimal-logo-light.png` } },
        about: [{ "@type": "Thing", name: "Staff augmentation" }, { "@type": "Thing", name: "Software engineering outsourcing" }],
        speakable: { "@type": "SpeakableSpecification", cssSelector: [".answer-box p", ".takeaways li"] },
      },
      {
        "@type": "FAQPage",
        "@id": `${url}#faq`,
        mainEntity: post.faqs.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
      },
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Home", item: site.url },
          { "@type": "ListItem", position: 2, name: "Insights", item: `${site.url}/insights` },
          { "@type": "ListItem", position: 3, name: post.title, item: url },
        ],
      },
    ],
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <article className="post" itemScope itemType="https://schema.org/BlogPosting">
        <header className="post-hero">
          <div className="container">
            <nav aria-label="Breadcrumb" className="crumbs mono">
              <ol>
                <li><Link href="/">Home</Link></li>
                <li><Link href="/insights">Insights</Link></li>
                <li aria-current="page">{post.category}</li>
              </ol>
            </nav>
            <h1 className="post-title" itemProp="headline">{post.title}</h1>
            <p className="lead post-dek">{post.dek}</p>
            <div className="post-meta mono dim">
              <span itemProp="author">By Decimal Tech</span>
              <span>Published <time dateTime={post.published} itemProp="datePublished">{fmtDate(post.published)}</time></span>
              {post.updated !== post.published && <span>Updated <time dateTime={post.updated} itemProp="dateModified">{fmtDate(post.updated)}</time></span>}
              <span>{post.readingMinutes} min read</span>
            </div>
          </div>
        </header>

        <div className="container">
          <section className="answer-box" aria-labelledby="short-answer">
            <p className="label" id="short-answer">Short answer</p>
            <p itemProp="abstract">{post.shortAnswer}</p>
          </section>

          <section className="takeaways" aria-labelledby="takeaways-t">
            <h2 id="takeaways-t" className="label label--plain">Key takeaways</h2>
            <ul>{post.takeaways.map((t) => <li key={t}>{t}</li>)}</ul>
          </section>

          <div className="post-layout">
            <aside className="post-toc" aria-label="On this page">
              <p className="mono dim">On this page</p>
              <ol>{post.toc.map((t) => <li key={t.id}><a href={`#${t.id}`}>{t.label}</a></li>)}</ol>
            </aside>
            <div className="prose-article" itemProp="articleBody">
              <Body />
              <section aria-labelledby="faq" className="faq">
                <h2 id="faq">Frequently asked questions</h2>
                {post.faqs.map((f) => (
                  <details key={f.q}>
                    <summary><h3>{f.q}</h3></summary>
                    <p>{f.a}</p>
                  </details>
                ))}
              </section>
            </div>
          </div>
        </div>
      </article>

      <section className="section section--rule">
        <div className="container">
          <ul className="related">
            <li><Link href="/teams#engagement" className="text-link">Engagement models: embedded engineer, pod, dedicated team</Link></li>
            <li><Link href="/engineering#philosophy" className="text-link">AI gives engineers leverage. Experience gives them judgment.</Link></li>
            <li><Link href="/engineering#process" className="text-link">How we vet the engineers we put in front of you</Link></li>
          </ul>
        </div>
      </section>
      <FinalCTA />
    </>
  );
}
