import type { Metadata } from "next";
import { PageHero } from "@/components/PageHero";
import { FinalCTA } from "@/components/sections/FinalCTA";
import Link from "next/link";
import { posts, fmtDate } from "@/lib/posts";
import { Arrow } from "@/components/Arrow";

export const metadata: Metadata = {
  title: "Insights — Engineering Teams, Staff Augmentation & AI-Native Engineering",
  description: "Notes from Decimal Tech on building engineering teams, embedded engineers, AI-native software engineering, streaming platforms and AWS.",
  alternates: { canonical: "/insights" },
};

/**
 * Articles from the V2 /blog should be migrated here as /insights/[slug]
 * (MDX or the existing CMS) with 301s from /blog/[slug].
 * Topic clusters below map to commercial search intent — not keyword stuffing.
 */
const clusters = [
  { area: "Engineering teams", topics: ["Engineering staff augmentation vs. outsourcing", "Embedded engineers: how they actually integrate", "Engineering pods for a product area", "Scaling an engineering team without a hiring freeze"] },
  { area: "AI-native engineering", topics: ["Where AI helps engineers — and where it doesn't", "AI in code review and testing", "Documentation as a by-product of the work"] },
  { area: "Platforms", topics: ["Streaming platform engineering", "Event-driven systems on AWS", "SaaS engineering for multi-user products"] },
];

export default function InsightsPage() {
  return (
    <>
      <PageHero
        title={<>Engineering notes<span className="dot">.</span></>}
        lead="Practical writing on building engineering teams, AI-native delivery and production systems — from the people doing the work."
      />
      <section className="section">
        <div className="container">
          <div className="section-head">
          </div>
          <ul style={{ display: "grid", gap: 16 }}>
            {posts.map((p) => (
              <li key={p.slug}>
                <Link href={`/insights/${p.slug}`} className="post-card">
                  <div>
                    <p className="mono dim">{p.category} · <time dateTime={p.published}>{fmtDate(p.published)}</time> · {p.readingMinutes} min</p>
                    <h2 className="post-card__title" style={{ marginTop: 14 }}>{p.title}</h2>
                  </div>
                  <div style={{ display: "grid", gap: 20 }}>
                    <p className="body">{p.dek}</p>
                    <span className="text-link" style={{ justifySelf: "start" }}>Read the guide <Arrow /></span>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <section className="section section--rule">
        <div className="container">
          <div className="section-head">
          </div>
          <ul className="insight-list">
            {clusters.map((c) => (
              <li key={c.area} className="insight">
                <p className="mono dim">{c.area}</p>
                <ul style={{ display: "grid", gap: 10 }}>
                  {c.topics.map((t) => <li key={t} className="insight__t">{t}</li>)}
                </ul>
                <p className="mono dim">Coming next</p>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <FinalCTA />
    </>
  );
}
