import { NextResponse } from "next/server";

export const runtime = "nodejs";

const MAX = 5000;
const clean = (v: unknown) => (typeof v === "string" ? v.trim().slice(0, MAX) : "");

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  // Honeypot — silently accept bots.
  if (clean(body.website)) return NextResponse.json({ ok: true });

  const lead = {
    name: clean(body.name),
    email: clean(body.email),
    company: clean(body.company),
    building: clean(body.building),
    capacity: clean(body.capacity),
    teamSize: clean(body.teamSize),
    stack: clean(body.stack),
    context: clean(body.context),
    wantsCall: body.wantsCall === "yes",
    submittedAt: new Date().toISOString(),
    source: "decimaltech.ai/contact (V3)",
  };
  if (!lead.name || !lead.company || !lead.building || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(lead.email)) {
    return NextResponse.json({ error: "Please complete the required fields." }, { status: 422 });
  }

  const text = [
    `Name: ${lead.name}`, `Email: ${lead.email}`, `Company: ${lead.company}`,
    `Capacity: ${lead.capacity || "-"}`, `Team size: ${lead.teamSize || "-"}`, `Stack: ${lead.stack || "-"}`,
    `Wants 30-min call: ${lead.wantsCall ? "YES" : "no"}`, "", "What are you building?", lead.building, "", "Context:", lead.context || "-",
  ].join("\n");

  const deliveries: Promise<Response>[] = [];
  if (process.env.RESEND_API_KEY && process.env.CONTACT_TO) {
    deliveries.push(
      fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: process.env.CONTACT_FROM || "Decimal Tech Website <website@decimaltech.ai>",
          to: process.env.CONTACT_TO.split(","),
          reply_to: lead.email,
          subject: `${lead.wantsCall ? "[CALL] " : ""}New enquiry — ${lead.company} (${lead.capacity || "capacity tbc"})`,
          text,
        }),
      })
    );
  }
  if (process.env.CONTACT_WEBHOOK_URL) {
    deliveries.push(fetch(process.env.CONTACT_WEBHOOK_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...lead, text }) }));
  }

  if (!deliveries.length) {
    console.error("[contact] No delivery configured (RESEND_API_KEY/CONTACT_TO or CONTACT_WEBHOOK_URL). Lead:", lead);
    return NextResponse.json({ error: "Our form is temporarily unavailable." }, { status: 503 });
  }

  const results = await Promise.allSettled(deliveries);
  const ok = results.some((r) => r.status === "fulfilled" && r.value.ok);
  if (!ok) {
    console.error("[contact] Delivery failed", results);
    return NextResponse.json({ error: "We couldn't send your message." }, { status: 502 });
  }
  return NextResponse.json({ ok: true });
}
