export const site = {
  name: "Decimal Tech",
  legalNames: ["Decimal Tech LLC", "Decimal Tech Pvt. Ltd."],
  url: process.env.NEXT_PUBLIC_SITE_URL || "https://decimaltech.ai",
  title: "Decimal Tech — Engineering Teams for Serious Software",
  description:
    "Decimal Tech builds and embeds experienced engineering teams into growing companies. Add senior engineers, engineering pods or dedicated teams that work directly inside your product organization.",
  email: "info@decimaltech.ai",
  phone: "+1 (720) 576-9024",
  phoneHref: "tel:+17205769024",
  whatsapp: "+977 9851128817",
  whatsappHref: "https://wa.me/9779851128817",
  twitter: "@decimaltech",
  /** On-site booking section (Calendly is embedded there). */
  bookingPath: "/contact#book-strategy-call",
  /** Decimal's 30-minute Calendly. Override per-environment with NEXT_PUBLIC_BOOKING_URL. */
  bookingUrl: process.env.NEXT_PUBLIC_BOOKING_URL || "https://calendly.com/decimaltech-info/30min",
};

export const bookingHref = site.bookingUrl || site.bookingPath;
export const bookingIsExternal = Boolean(site.bookingUrl);

export const nav = [
  { href: "/teams", label: "Teams" },
  { href: "/engineering", label: "Engineering" },
  { href: "/about", label: "About" },
  { href: "/insights", label: "Insights" },
];

export const offices = [
  {
    region: "United States",
    city: "Brighton, Colorado",
    role: "Headquarters",
    entity: "Decimal Tech LLC",
    address: "2785 Black Hawk Pl, Brighton, CO 80601, USA",
    tz: "America/Denver",
  },
  {
    region: "Nepal",
    city: "Kathmandu",
    role: "Engineering centre",
    entity: "Decimal Tech Pvt. Ltd.",
    address: "Kalanki-14, Kathmandu, Nepal",
    tz: "Asia/Kathmandu",
  },
  {
    region: "Australia",
    city: "Melbourne",
    role: "APAC presence",
    entity: "",
    address: "",
    tz: "Australia/Melbourne",
  },
];
