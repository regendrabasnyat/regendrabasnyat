/**
 * Map first names to real photographs in /public/images/team/.
 * Leave a value undefined to show the labelled placeholder.
 * e.g. subash: "/images/team/subash.jpg"
 */
export const photos: Record<string, string | undefined> = {
  subash: undefined,
  anup: undefined,
  gaurab: undefined,
  regendra: undefined,
  dipesh: undefined,
  prabesh: undefined,
  girban: undefined,
};
export const photoFor = (name: string) => photos[name.toLowerCase()];
