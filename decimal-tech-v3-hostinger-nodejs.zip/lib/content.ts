/**
 * Single source of truth for V3 copy.
 * FACTUAL RULE: nothing here may state a metric, client, technology or ownership
 * that is not verified. Items needing sign-off are tagged `// VERIFY`.
 */

export const teamOfferings = [
  {
    id: "embedded",
    title: "One Engineer",
    body: "A senior engineer added directly to your existing team. The usual starting point.",
  },
  {
    id: "pods",
    title: "A Team",
    body: "More engineers, aligned around your product and roadmap as the work grows.",
  },
  {
    id: "dedicated",
    title: "A Pod",
    body: "A complete engineering unit working as an extension of your organization.",
  },
  {
    id: "leadership",
    title: "Technical Leadership",
    body: "Senior technical leadership for architecture, engineering decisions and delivery.",
  },
];

export const teamModel = [
  "What are you building?",
  "What engineering work is required?",
  "What capabilities are needed?",
  "Who should own it?",
  "Build the team.",
  "Start shipping.",
];

export const engineers = [
  {
    name: "Subash",
    role: "Co-Founder · CTO",
    body: "Leads technical architecture and engineering direction at Decimal Tech.",
    focus: ["Architecture", "Engineering Leadership", "Product Engineering", "Technical Direction"],
    lead: true,
  },
  {
    name: "Dipesh",
    role: "Full-Stack Developer",
    body: "Product engineering across application interfaces, backend systems and production workflows.",
    focus: ["Interfaces", "Backend", "Production workflows"],
  },
  {
    name: "Prabesh",
    role: "Full-Stack Developer",
    body: "Full-stack product development, integrations and feature delivery.",
    focus: ["Full-stack", "Integrations", "Feature delivery"],
  },
  {
    name: "Girban",
    role: "Full-Stack Developer",
    body: "Application engineering and production feature development.",
    focus: ["Application engineering", "Production features"],
  },
];

export const capabilities = [
  {
    id: "streaming",
    title: "Streaming & Media",
    body: "Live streaming · OTT · Video · Media processing · Real-time systems",
  },
  {
    id: "saas",
    title: "SaaS & Product",
    body: "SaaS · Web · Mobile · APIs · Consumer products",
  },
  {
    id: "marketplace",
    title: "Marketplaces & Commerce",
    body: "Marketplaces · Auctions · Transactions · E-commerce",
  },
  {
    id: "enterprise",
    title: "Enterprise & Government",
    body: "Enterprise software · Government systems · Workflow platforms",
  },
  {
    id: "cloud",
    title: "Cloud & Modern Engineering",
    body: "AWS · Distributed systems · Cloud infrastructure · DevOps",
  },
];
export const principles = [
  { title: "Founder-led", body: "Talk directly with the people responsible for the company." },
  { title: "Experienced engineers", body: "Engineers capable of owning work." },
  { title: "Embedded teams", body: "Our people work inside your existing product organization." },
  { title: "AI-native", body: "AI is part of how we research, build, test and document." },
  { title: "Production-minded", body: "We care about what happens after the code is merged." },
];

export const engagementModels = [
  {
    id: "embedded-engineer",
    title: "One Engineer",
    body: "One experienced engineer joins your existing team and starts shipping inside it.",
    bestFor: ["A role you can't fill", "Feature delivery", "Backend / frontend capacity", "Platform work", "A specialist skill"],
    cta: "Hire a Top-Tier Engineer",
    featured: true,
  },
  {
    id: "engineering-team",
    title: "Team",
    body: "More engineers, aligned around your product and roadmap.",
    bestFor: ["Growing roadmaps", "Major features", "Parallel workstreams", "Scaling an existing team"],
    cta: "Build Your Team",
  },
  {
    id: "engineering-pod",
    title: "Pod",
    body: "A complete engineering unit with the skills to own a larger scope.",
    bestFor: ["A product area end to end", "Platform expansion", "Multiple product streams", "Long-term development"],
    cta: "Build a Pod",
  },
];

export const howItWorks = [
  { title: "Tell us what you're building", body: "Your product, roadmap, stack and current engineering gap." },
  { title: "Understand the work", body: "We understand the actual engineering requirements." },
  { title: "Build the team", body: "We match capabilities, seniority and ownership." },
  { title: "Meet the engineers", body: "You speak directly with the people who may join your team." },
  { title: "Integrate", body: "Same repositories. Same tools. Same communication." },
  { title: "Ship", body: "The team works inside the product organization and keeps shipping." },
];

export const dontDo = [
  "Sell resumes",
  "Throw random developers at projects",
  "Hide engineers behind account managers",
  "Optimize for headcount",
  "Build without understanding the product",
];

export const founders = [
  {
    name: "Subash",
    role: "Co-Founder · CTO",
    short: "Architecture + Engineering Leadership",
    story: [
      "Subash leads technical architecture and engineering direction at Decimal Tech, and holds a CTO role with a product company the team works with.",
      "His background includes senior engineering work at A Cloud Guru, where he worked as a Lead Software Engineer / Lead Developer. A Cloud Guru later became part of the Pluralsight technology-learning ecosystem.",
    ],
    strengths: ["Architecture", "Engineering Leadership", "Product Engineering", "Technical Direction"],
    location: "Nepal",
  },
  {
    name: "Anup",
    role: "Co-Founder · Head of Engineering",
    short: "US + Engineering Teams",
    story: [
      "US-based engineering leader with experience across MVPs, scale-ups and enterprise products.",
      "Before Decimal, he worked with a top-tier US technology agency serving Fortune 500 companies, working alongside experienced engineering teams on complex software projects. At Decimal, he leads engineering operations, team development and supports US client relationships.",
    ],
    strengths: ["Senior Engineering", "MVP → Scale-up → Enterprise", "Engineering Management", "Team Building", "US Client / HQ Coordination"],
    location: "United States",
  },
  {
    name: "Gaurab",
    role: "Co-Founder · Managing Director",
    short: "Technical Sales + Enterprise / Government",
    story: [
      "Gaurab brings a technical-sales background spanning enterprise technology, cybersecurity and government-focused solutions.",
      "His previous work includes selling and supporting technology products and solutions from major technology ecosystems, including Microsoft-related products, as well as cybersecurity solutions for government organizations and large corporations in Nepal.",
    ],
    strengths: ["Technical Sales", "Enterprise Technology", "Cybersecurity", "Government Solutions", "Business Development"],
    location: "Nepal",
  },
  {
    name: "Regendra",
    role: "Co-Founder · Head of Staffing",
    short: "Teams + Talent + Client Relationships",
    story: [
      "Regendra leads staffing, talent and client relationships at Decimal Tech.",
      "His background sits at the intersection of business, product and technology — working with engineering teams, clients and product initiatives across international markets.",
    ],
    strengths: ["Staffing", "Talent", "Client Relationships", "Product", "International Markets"],
    location: "Nepal",
  },
];

/** Company-level stack (supplied by Decimal, Sept 2026). Do NOT attach to individual projects. */
export const techStackIntro =
  "Decimal Tech builds modern, cloud-native software using a senior engineering stack designed for scalable production systems.";
export const techStack = [
  { group: "Core", items: ["TypeScript", "Node.js", "React", "Next.js"] },
  { group: "Cloud & Infrastructure", items: ["AWS", "Lambda", "API Gateway", "DynamoDB", "SQS", "EventBridge"] },
  { group: "Infrastructure as Code", items: ["SST", "AWS CDK", "Terraform", "Pulumi"] },
  { group: "DevOps", items: ["GitHub Actions", "Docker", "ECS", "Kubernetes"] },
  { group: "Backend", items: ["Node.js", "Python", "Laravel", "Ruby on Rails"] },
  { group: "AI", items: ["OpenAI", "Anthropic", "AI/ML integrations"] },
  { group: "Architecture", items: ["Serverless", "Event-driven", "Cloud-native", "Scalable SaaS", "High-traffic platforms"] },
];
export const techStackOutro =
  "We combine modern engineering practices with AI-native development to build, modernize and scale production software.";


/** Our Story — why the four founders came together. Supplied by Decimal, Sept 2026. */
export const storyLead =
  "Decimal began with four childhood school friends who took different paths through technology, business and engineering — and eventually came back together around the same idea.";

export const storyTimeline = [
  { when: "20 years ago", title: "Four childhood school friends", body: "Different schools of thought, different paths — technology, business and engineering." },
  { when: "June 2025", title: "Anup returns from the US", body: "He comes back to Nepal with a plan to build a technology services company or a technology product business, after years working alongside experienced engineering teams in the US." },
  { when: "The idea", title: "Anup + Gaurab start exploring", body: "They begin working out how to build something of that standard from Nepal." },
  { when: "The four", title: "Regendra joins, then Subash", body: "Regendra brings the business and product perspective. Subash, working in the same industry in Australia, completes the four." },
  { when: "Decimal", title: "An existing company, re-formed", body: "Decimal was already incorporated in Nepal. The four re-formed it around themselves and one belief." },
  { when: "Today", title: "A company built on a standard", body: "A year of testing that belief on real work, with a hiring process refined through real engineering teams." },
];

export const storyBelief =
  "Nepal has exceptional engineers — and with the right standards, they can build and work at the highest level for companies anywhere in the world.";

export const storyClose = [
  "For the past year, we have been putting that belief to the test. We built and refined our hiring process through real work and real engineering teams.",
  "Every Decimal engineer goes through rigorous technical and non-technical interviews before joining us. We are not trying to hire at volume. We are looking for the best engineers we can confidently put in front of our clients.",
];

export const hiringPrinciples = [
  { title: "Technical depth", body: "Can they actually build?" },
  { title: "Problem solving", body: "Can they think beyond the ticket?" },
  { title: "Communication", body: "Can they work effectively with a distributed team?" },
  { title: "Ownership", body: "Can they take responsibility for outcomes?" },
  { title: "AI-native engineering", body: "Can they use modern AI tools while keeping engineering judgment in their own hands?" },
];


/* ------------------------------------------------------------------ *
 * Oct 2026 refinement — the hiring problem, what the client gets,
 * the process, the philosophy and honest proof. No client names.
 * ------------------------------------------------------------------ */

export const problemChain = ["Sourcing", "Screening", "Technical interviews", "Filtering", "Hiring", "Onboarding"];

export const whatYouGet = [
  { id: "vetted", title: "Pre-vetted", body: "Technical and non-technical evaluation before you ever see a profile." },
  { id: "team-ready", title: "Team-ready", body: "Can communicate, collaborate and work inside an existing engineering team." },
  { id: "experienced", title: "Experienced", body: "Engineers with real software development experience behind them." },
  { id: "ai-native", title: "AI-native", body: "Modern AI tools used for research, development, testing and documentation." },
  { id: "judgment", title: "Engineering judgment", body: "AI provides leverage. Experience provides judgment." },
];

export const processSteps = [
  { title: "Your need", body: "What you're building, the gap in the team, and what the engineer has to own." },
  { title: "We source", body: "We go and find people who fit that specific need — not whoever is on a bench." },
  { title: "Technical + human vetting", body: "Can they build it? Can they work inside your team? Both are interviewed for." },
  { title: "You meet the engineer", body: "You talk to the person, not an account manager, and decide for yourself." },
  { title: "They join your team", body: "Your repositories, your tools, your standups. You keep the roadmap." },
];

export const philosophy = {
  line: "AI gives engineers leverage. Experience gives them judgment.",
  parts: [
    { title: "Experience", body: "Years of shipping real software, and the judgment that comes with it." },
    { title: "AI tools", body: "Research, development, testing and documentation, done faster." },
    { title: "Ownership", body: "Someone accountable for the outcome, not just the ticket." },
  ],
  result: "Better engineering",
};

export const proof = {
  headline: "The model is already working.",
  body: [
    "We're a young company, but this isn't an untested idea. We've already been embedding engineers into real teams and working through real product and engineering problems.",
    "The experience has reinforced something simple: when the engineer is right, adding engineering capacity doesn't need to be complicated.",
  ],
  stamp: "Real engineers. Real teams. Real work.",
};

export const aboutUs = {
  headline: "We're young. Our experience isn't.",
  body: [
    "Decimal is a young, growing engineering company run by people who have spent years working in software, engineering teams and technology businesses.",
    "We've experienced the same hiring and engineering-capacity problems our clients face. So we built Decimal around solving one of them: helping companies add good engineers without building the entire hiring process themselves.",
    "We're growing, we're learning, and we're ready for the work.",
  ],
  stamp: "We're ready for the work.",
};
