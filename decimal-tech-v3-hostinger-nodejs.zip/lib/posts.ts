/**
 * Insights posts. Written for SEO (search intent + structure), AEO (direct
 * answers, question headings, FAQ schema) and GEO (clear entity statements,
 * definitions, quotable passages, llms.txt + RSS).
 */
export type Faq = { q: string; a: string };
export type Post = {
  slug: string;
  title: string;
  seoTitle: string;
  description: string;
  dek: string;
  category: string;
  published: string; // ISO date
  updated: string;
  readingMinutes: number;
  keywords: string[];
  shortAnswer: string;
  takeaways: string[];
  toc: { id: string; label: string }[];
  faqs: Faq[];
};

export const posts: Post[] = [
  {
    slug: "engineering-staff-augmentation-vs-outsourcing",
    title: "Engineering staff augmentation vs. outsourcing: how to add capacity without losing ownership",
    seoTitle: "Engineering Staff Augmentation vs. Outsourcing (2026 Guide)",
    description:
      "What engineering staff augmentation is, how it differs from outsourcing and hiring, when to choose an embedded engineer, a pod or a dedicated team, and how to evaluate a partner.",
    dek: "Staff augmentation, outsourcing and hiring all add engineering capacity. They differ on one thing that matters more than price: who owns the work.",
    category: "Engineering teams",
    published: "2026-09-21",
    updated: "2026-09-21",
    readingMinutes: 9,
    keywords: [
      "engineering staff augmentation",
      "staff augmentation vs outsourcing",
      "embedded engineers",
      "dedicated engineering team",
      "engineering pods",
      "remote engineering teams",
      "hire full-stack engineers",
    ],
    shortAnswer:
      "Engineering staff augmentation adds external engineers directly into your team: they work in your repositories, tools and rituals, and your product leadership directs the work. Outsourcing hands a scope of work to a vendor that manages delivery itself. Choose augmentation when you want to keep product ownership and move faster; choose outsourcing when you want to hand off a well-defined, separable project.",
    takeaways: [
      "The real difference between augmentation and outsourcing is ownership — who decides what gets built and how.",
      "Augmentation works best when you already have product direction and need more engineers who can execute it.",
      "Match the model to the work: one embedded engineer for a capacity gap, a pod for a product area, a dedicated team for multiple streams.",
      "Meet the actual engineers before they join. Evaluate people, not a vendor's sales deck.",
      "AI tools make good engineers faster; they do not replace the need for engineers who own outcomes.",
    ],
    toc: [
      { id: "what-is-staff-augmentation", label: "What is engineering staff augmentation?" },
      { id: "vs-outsourcing", label: "How is it different from outsourcing?" },
      { id: "comparison", label: "Augmentation vs. outsourcing vs. hiring" },
      { id: "which-model", label: "Embedded engineer, pod or dedicated team?" },
      { id: "integration", label: "How do augmented engineers integrate?" },
      { id: "ai", label: "What changes with AI-native engineering?" },
      { id: "evaluate", label: "How to evaluate a partner" },
      { id: "glossary", label: "Glossary" },
      { id: "faq", label: "FAQ" },
    ],
    faqs: [
      {
        q: "What is engineering staff augmentation?",
        a: "Engineering staff augmentation is a way to add capacity by bringing external engineers into your existing team. They work in your codebase, tools and communication channels, and your product and engineering leadership directs their work.",
      },
      {
        q: "Is staff augmentation the same as outsourcing?",
        a: "No. With outsourcing, a vendor takes responsibility for delivering a defined scope and manages the team itself. With staff augmentation, the engineers join your team and you keep ownership of product decisions, priorities and architecture.",
      },
      {
        q: "When should a company use staff augmentation instead of hiring?",
        a: "Use staff augmentation when you need experienced engineers sooner than a hiring process allows, when the need may change over time, or when you want to test a new product area before committing to permanent headcount.",
      },
      {
        q: "What is an engineering pod?",
        a: "An engineering pod is a small group of engineers assembled around one product area or roadmap theme. It is larger than a single embedded engineer and smaller than a dedicated team, and it usually works as a unit inside your organization.",
      },
      {
        q: "How do you keep quality high with augmented engineers?",
        a: "Treat them as part of the team: the same code review standards, the same definition of done, the same access to product context. Meet the engineers before they start, and choose a partner whose engineers are expected to own outcomes rather than close tickets.",
      },
      {
        q: "Does Decimal Tech provide engineering staff augmentation?",
        a: "Yes. Decimal Tech builds and embeds experienced engineering teams — embedded engineers, engineering pods and dedicated teams — that work directly inside client product organizations, with offices in the United States, Nepal and Australia.",
      },
    ],
  },
];

export const getPost = (slug: string) => posts.find((p) => p.slug === slug);
export const fmtDate = (iso: string) =>
  new Date(iso + "T00:00:00Z").toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric", timeZone: "UTC" });
