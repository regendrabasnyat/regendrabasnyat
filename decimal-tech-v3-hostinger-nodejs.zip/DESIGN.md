# Decimal Tech — design system (as shipped)

Paper-and-ink editorial system. One accent (the logo's red "point"). Rules instead of cards. Confidence through scale and whitespace, not weight or decoration.

## Tokens (`app/globals.css`, `:root` + `:root[data-theme="dark"]`)
| Token | Light | Dark | Use |
|---|---|---|---|
| `--paper` / `--paper-2` | #f4f3ef / #ecebe5 | #0f1013 / #15171b | page, alternating sections |
| `--surface` | #ffffff | #191b20 | panels, inputs |
| `--ink` / `--ink-2` / `--muted` | #0a0b0d / #33363d / #62666f | #f2f2ef / #c6c9d0 / #9a9ea8 | text hierarchy |
| `--line` / `--line-strong` | 12% / 24% ink | 11% / 22% white | rules, borders |
| `--accent` / `--accent-ink` | #ee3b24 / #c42a15 | #ee3b24 / #ff6f5a | the point; AA-safe variant for small text |
| `--block` | #0a0b0d | #1f2229 | inverse feature blocks (always light text) |
| `--night` / `--night-2` | #0b0c0f / #15171c | #07080a / #121419 | always-dark sections |

Type: Geist Sans (display + body), Geist Mono — only for data, metadata, counters and system lines, never as decoration. Display: uppercase, weight 550–600, tracking −0.035/−0.04em, max 4.6rem. Body measure ≤ 60ch; article prose 68ch.

Space: `--gutter` 16→40px, `--max` 1320px, `--section` 88→168px, radii 6/10px, nav 64px.

## Rules
- **No kickers.** Headings carry their own weight; the hero eyebrow is the one briefed exception. No 01/02/03 section numbering — numerals only where sequence is information (process steps).
- **Rules over cards.** Thin 1px grids; cards only where hierarchy needs a container. No nested cards, no coloured side-tabs (1px max), no gradient text, no glass.
- **One authored motion moment** (hero line reveal + capacity panel). Elsewhere: state transitions only. Everything respects `prefers-reduced-motion`.
- **Inverse blocks** (`--block`) stay dark in both themes so the engineer-first card and case study read the same way.
- **Browser surfaces are themed**: selection, caret, scrollbar, focus ring, underline offset, tabular numerals.

## Components
`Nav` (sticky, theme toggle, full-screen mobile menu) · `Footer` · `ButtonLink` (`primary` / `ghost` / `light` / `ghost-light` / `quiet`, `--lg`) · `PageHero` · `Portrait` (real photo or labelled placeholder — never a generated face) · `Reveal` · `CalendlyEmbed` · `ThemeToggle`.

Sections: `Hero` (Engineer→Team→Pod tablist + capacity panel) · `Problem` · `EngineeringTeams` · `TeamModel` · `MemoriesCase` (sticky rail) · `Engineers` · `AILayer` + `AgentAvatar` · `Experience` · `TechStack` · `Streaming` · `Portfolio` · `WhyDecimal` · `EngagementModels` (engineer-dominant) · `HowItWorks` · `Founders` · `OurStory` · `HiringStandard` · `GlobalPresence` · `FinalCTA`.

## Content rules
Copy lives in `lib/content.ts`. No invented metrics, clients, rankings or "top 1%" claims. Client facts are attributed to their source. Individual names are not attached to portfolio projects — they are the founders' previous work.
