// Builds a static copy of the site for Hostinger shared hosting (public_html).
// Output: ./out  (upload its CONTENTS into public_html)
import { execSync } from "node:child_process";
import { renameSync, existsSync, cpSync } from "node:fs";

const api = "app/api", parked = ".api-parked";
if (existsSync(api)) renameSync(api, parked); // route handlers can't be statically exported
try {
  execSync("next build", {
    stdio: "inherit",
    env: { ...process.env, STATIC_EXPORT: "1", NEXT_PUBLIC_CONTACT_ENDPOINT: "/contact.php" },
  });
  cpSync("static-hosting", "out", { recursive: true });
  console.log("\n✓ Static site ready in ./out — upload its contents to public_html");
} finally {
  if (existsSync(parked)) renameSync(parked, api);
}
