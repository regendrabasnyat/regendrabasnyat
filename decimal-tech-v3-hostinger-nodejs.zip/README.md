# Decimal Tech — Website V3

**Top-tier engineers. Built around your work.**

Next.js 16 (App Router) · React 19 · TypeScript · plain CSS design system · Geist (self-hosted via `geist` package). No UI/animation libraries.

## Run locally
```bash
npm install
cp .env.example .env.local   # fill in contact delivery + optional booking URL
npm run dev                  # http://localhost:3000
```

## Build
```bash
npm run build && npm start
```

## Deploy (Vercel — matches the V2 Next.js setup)
1. Push this folder to the website repo (new branch, e.g. `v3`).
2. Import/attach in Vercel, framework preset **Next.js**.
3. Set env vars from `.env.example`:
   - `NEXT_PUBLIC_SITE_URL=https://decimaltech.ai`
   - `RESEND_API_KEY` + `CONTACT_TO` **or** `CONTACT_WEBHOOK_URL` (form returns 503 until one is set)
   - `NEXT_PUBLIC_BOOKING_URL` only if a real Calendly/Cal.com link exists
4. Preview deploy → QA → promote to production.

## Where things live
| What | File |
|---|---|
| All copy (single source of truth) | `lib/content.ts` |
| Contact details, offices, nav, booking | `lib/site.ts` |
| Team photos | `lib/photos.ts` + `public/images/team/<name>.jpg` |
| Design tokens + components CSS | `app/globals.css` |
| Homepage section order | `app/page.tsx` |
| Legacy redirects (V2 → V3) | `next.config.ts` |
| Contact API | `app/api/contact/route.ts` |

## Before launch
See `V3_BUILD_REPORT.md` → "Real assets still required" and "Claims requiring verification".

## Deploy to Hostinger

### Option A — Business / Cloud plan (Node.js Web App, full features)
1. hPanel → **Websites → Add Website → Deploy Web App → Upload your website files**.
2. Upload `decimal-tech-v3-hostinger-nodejs.zip` (package.json at the zip root, no node_modules).
3. Framework: **Next.js** · Node **22.x** · Build `npm run build` · Start `npm start`.
4. Add env vars from `.env.example` (contact delivery!), deploy, then connect `decimaltech.ai`.

### Option B — Premium / Single shared plan (static, any plan)
1. `npm run build:static` → produces `./out` (already packaged as `decimal-tech-v3-hostinger-static.zip`).
2. hPanel → **Files → File Manager → public_html**. Back up / move the old site files out first.
3. Upload the zip into `public_html` → right-click → **Extract** (files must sit directly in public_html, incl. `.htaccess`).
4. `contact.php` sends enquiries with PHP mail() from `website@decimaltech.ai` to `info@decimaltech.ai` — create that mailbox (or change `$FROM`) in Hostinger Email.
5. `.htaccess` handles HTTPS, www → apex, and all V2 → V3 redirects.
