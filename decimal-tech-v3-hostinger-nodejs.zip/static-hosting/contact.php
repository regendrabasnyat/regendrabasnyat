<?php
/**
 * Decimal Tech V3 — contact form handler for Hostinger shared hosting.
 * Sends enquiries to $TO using PHP mail() from a @decimaltech.ai address
 * (the domain's mailbox must exist in Hostinger Email for best deliverability).
 */
$TO   = 'info@decimaltech.ai';
$FROM = 'website@decimaltech.ai';

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error' => 'Method not allowed.']); exit; }

$in = json_decode(file_get_contents('php://input'), true);
if (!is_array($in)) { http_response_code(400); echo json_encode(['error' => 'Invalid request.']); exit; }

function c($v) { return is_string($v) ? trim(mb_substr(str_replace(["\r", "\0"], '', $v), 0, 5000)) : ''; }
if (c($in['website'] ?? '') !== '') { echo json_encode(['ok' => true]); exit; } // honeypot

$lead = [
  'name' => c($in['name'] ?? ''), 'email' => c($in['email'] ?? ''), 'company' => c($in['company'] ?? ''),
  'building' => c($in['building'] ?? ''), 'capacity' => c($in['capacity'] ?? ''), 'teamSize' => c($in['teamSize'] ?? ''),
  'stack' => c($in['stack'] ?? ''), 'context' => c($in['context'] ?? ''), 'wantsCall' => ($in['wantsCall'] ?? '') === 'yes',
];
if ($lead['name'] === '' || $lead['company'] === '' || $lead['building'] === '' || !filter_var($lead['email'], FILTER_VALIDATE_EMAIL)) {
  http_response_code(422); echo json_encode(['error' => 'Please complete the required fields.']); exit;
}

$subject = ($lead['wantsCall'] ? '[CALL] ' : '') . 'New enquiry — ' . $lead['company'] . ' (' . ($lead['capacity'] ?: 'capacity tbc') . ')';
$body = "Name: {$lead['name']}\nEmail: {$lead['email']}\nCompany: {$lead['company']}\n"
      . "Capacity: " . ($lead['capacity'] ?: '-') . "\nTeam size: " . ($lead['teamSize'] ?: '-') . "\nStack: " . ($lead['stack'] ?: '-') . "\n"
      . "Wants 30-min call: " . ($lead['wantsCall'] ? 'YES' : 'no') . "\n\nWhat are you building?\n{$lead['building']}\n\nContext:\n" . ($lead['context'] ?: '-') . "\n\n— decimaltech.ai/contact (V3)";
$headers = "From: Decimal Tech Website <$FROM>\r\nReply-To: {$lead['email']}\r\nContent-Type: text/plain; charset=UTF-8";

if (!mail($TO, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $headers)) {
  http_response_code(502); echo json_encode(['error' => "We couldn't send your message."]); exit;
}
echo json_encode(['ok' => true]);
